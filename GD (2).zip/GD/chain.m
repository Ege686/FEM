classdef chain
    %CHAİN Summary of this class goes here
    %   Detailed explanation goes here
    
    methods(Static)
        function d = dMSE(Q)
            d=Q;
        end
        function d = dL(el,ENL,i,x)
            if el(1)==i
                j=el(2);
            else
                j=el(1);
            end
            d=(ENL(i,x)-ENL(j,x))/sqrt((ENL(i,1)-ENL(j,1))^2+(ENL(i,2)-ENL(j,2))^2);
        end
        function d=dW(p,A)
            d=p*A;
        end
        function d = dudL(K,el,n,ENL,F,v,i,DOFs)
            l=sqrt((ENL(el(1),1)-ENL(el(2),1))^2+(ENL(el(1),2)-ENL(el(2),2))^2);
            alfa=atan((ENL(el(1),2)-ENL(el(2),2))/(ENL(el(1),1)-ENL(el(2),1)));
            if alfa<0
                alfa=abs(alfa)+pi/2;
            end
            k=[cos(alfa)^2 sin(alfa)*cos(alfa) -cos(alfa)^2 -cos(alfa)*sin(alfa);
               sin(alfa)*cos(alfa) sin(alfa)^2 -sin(alfa)*cos(alfa) -sin(alfa)^2;
               -cos(alfa)^2 -sin(alfa)*cos(alfa) cos(alfa)^2 sin(alfa)*cos(alfa);
               -sin(alfa)*cos(alfa) -sin(alfa)^2 sin(alfa)*cos(alfa) sin(alfa)^2];
            A= 1*10^(-4);
            E= 210*10^9;
            k=(-E*A/l^2)*k;
            dK=zeros(size(ENL,1)*2,size(ENL,1)*2);
            for r=1:size(el,2)
                for dim=1:2
                    for c=1:size(el,2)
                        for dimm=1:2
                            dK(ENL(el(r),6+dim),ENL(el(c),6+dimm))=k(dim+2*(r-1),dimm+2*(c-1));
                        end
                    end
                end
            end
            iK=inv(K);
            %iK=rescale(iK,-1, 1);
            %or=order(iK);
            %o=max(or(:,:));
            %o=max(o);
            %iK=iK/10^o;
            dK=-iK*dK*iK;
            d=dK(ENL(n,6+v),:)*F;
        end
        function d=duda(K,el,n,ENL,F,v,i,DOFs)
            l=sqrt((ENL(el(1),1)-ENL(el(2),1))^2+(ENL(el(1),2)-ENL(el(2),2))^2);
            alfa=atan((ENL(el(1),2)-ENL(el(2),2))/(ENL(el(1),1)-ENL(el(2),1)));
            if alfa<0
                alfa=abs(alfa)+pi/2;
            end
            k=[-2*sin(alfa)*cos(alfa) -sin(alfa)^2+cos(alfa)^2 2*sin(alfa)*cos(alfa) -cos(alfa)^2+sin(alfa)^2;
                -sin(alfa)^2+cos(alfa)^2 2*sin(alfa)*cos(alfa) -cos(alfa)^2+sin(alfa)^2 -2*cos(alfa)*sin(alfa);
                2*sin(alfa)*cos(alfa) -cos(alfa)^2+sin(alfa)^2 -2*sin(alfa)*cos(alfa) -sin(alfa)^2+cos(alfa)^2;
                -cos(alfa)^2+sin(alfa)^2 -2*sin(alfa)*cos(alfa) -sin(alfa)^2+cos(alfa)^2 2*sin(alfa)*cos(alfa)];
            A= 1*10^(-4);
            E= 210*10^9;
            k=k*(E*A/l);
            dK=zeros(size(ENL,1)*2,size(ENL,1)*2);
            for r=1:size(el,2)
                for dim=1:2
                    for c=1:size(el,2)
                        for dimm=1:2
                            dK(ENL(el(r),6+dim),ENL(el(c),6+dimm))=k(dim+2*(r-1),dimm+2*(c-1));
                        end
                    end
                end
            end
            iK=inv(K);
            dK=-iK*dK*iK;
            %iK=rescale(iK,-1, 1);
            d=dK(ENL(n,6+v),:)*F;
        end
        function d=da(ENL,el,i,v)
            if el(1)==i
                j=2;
                i=1;
            else
                j=1;
                i=2;
            end
            if v==1
                n=-(ENL(el(i),2)-ENL(el(j),2))/(ENL(el(i),1)-ENL(el(j),1))^2;
                dn=1+((ENL(el(i),2)-ENL(el(j),2))/(ENL(el(i),1)-ENL(el(j),1)))^2;
                d=n/dn;
            end
            if v==2
                n=1/(ENL(el(i),1)-ENL(el(j),1));
                dn=1+((ENL(el(i),2)-ENL(el(j),2))/(ENL(el(i),1)-ENL(el(j),1)))^2;
                d=n/dn;
            end
        end
        function d = dudu(ENL,k,v,u)
            d=ENL(k,8+v)/u;
        end
    end
end

