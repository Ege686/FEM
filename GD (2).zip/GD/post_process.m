
function post_process(NL, EL, ENL, E, Node_flag, Element_flag, mag,fig)
    NoN = size(NL, 1);
    NoE = size(EL, 1);
    
    figure(fig)
    %%% Draw the undeformed configuration %%%
    %axis equal
    % Plot elements
for i = 1:NoE
    H = plot([NL(EL(i, 1), 1), NL(EL(i, 2), 1)], [NL(EL(i, 1), 2), NL(EL(i, 2), 2)],'LineWidth', 3, 'Color','k');
    hold on
    H.Color(4)= 0.2;
end

    % Plot nodes
%for i = 1:NoN
    %plot(NL(i, 1), NL(i, 2), 'o', 'MarkerSize', 10, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r');
%end

    %%% Draw the deformed configuration %%%
colorMap = jet;
colormap(colorMap);

    % Plot elements with stress distribution
for i = 1:NoE
    x = [ENL(EL(i,1),1) + mag * ENL(EL(i,1),9), ENL(EL(i,2),1) + mag * ENL(EL(i,2),9)];
    y = [ENL(EL(i,1),2) + mag * ENL(EL(i,1),10), ENL(EL(i,2),2) + mag * ENL(EL(i,2),10)];
    z = zeros(size(x));
    sigma = E * (sqrt((ENL(EL(i,1),9) - ENL(EL(i,2),9))^2 + (ENL(EL(i,1),10) - ENL(EL(i,2),10))^2) ...
        / sqrt((ENL(EL(i,1),1) - ENL(EL(i,2),1))^2 + (ENL(EL(i,1),2) - ENL(EL(i,2),2))^2));
    col = [sigma sigma];
    surface([x;x], [y;y], [z;z], [col;col], 'facecol', 'no', 'edgecol', 'interp', 'linew', 4);
end

colorbar

%%% Plot Element Numbers %%%
%if isequal(Element_flag, 'on')

  %  for i = 1:NoE
   %     text((ENL(EL(i,1),1) + mag * ENL(EL(i,1),9) + ENL(EL(i,2),1) + mag * ENL(EL(i,2),9)) / 2,(ENL(EL(i,1),2)+mag * ENL(EL(i,1),10)+ENL(EL(i,2),2)+mag *ENL(EL(i,2),10))/2, ...
    %        num2str(i),'Color','k','FontSize',16,'HorizontalAlignment','center');
    %end
%end

%%% Plot Nodes %%%
for i = 1:NoN
   plot(ENL(i,1)+mag*ENL(i,9),ENL(i,2)+mag*ENL(i,10),'o','MarkerSize',5,'MarkerEdgeColor','k','MarkerFaceColor',[0,0.7,0.9]);
end

if isequal(Node_flag,'on')
    for i= 1:NoN

        text(ENL(i,1)+mag*ENL(i,9),ENL(i,2)+mag*ENL(i,10),num2str(i),'Color','w','FontSize',12,'HorizontalAlignment','center');
    end
end

hold off

end