function [coefs,res,inps]=polynomial(PD,NC,deg,num,xx,disps,NL,BC,EL)
    dim=PD*NC;
    deg=deg*dim;
    inps=ones(deg+1, deg+1);
    inpss=ones(deg+1, size(xx,2));
    r=linspace(1,num,deg+1);
    reso=zeros(deg+1,1);
    for i=1:deg+1
        for x=1:size(xx,2)
            inpss(i,x)=xx(floor(r(i)),x);
        end
    end
    
    for y=1:deg+1
        for x=1:size(xx,2)
            for d=1:deg/dim+1
                xa=deg/dim*(x-1)+d;
                cef=1;
                for e=1:size(xx,2)
                    if e~=x
                        cef=cef*1;
                    end
                end
                inps(y,xa)=cef*inpss(y,x)^(deg/dim-d+1);
            end
        end
        reso(y)=disps(floor(r(y)),1);
    end
    coefs=(inps'*inps)\(inps'*reso);
    res=zeros(1,num);
    for y=1:size(xx,1)
        for x=1:size(xx,2)
            for d=deg/dim:-1:1
                xa=deg/dim*(x-1)+(deg/dim-d+1);
                cef=1;
                for e=1:size(xx,2)
                    if e~=x
                        cef=cef*1;
                    end
                end
                res(y)=res(y)+cef*coefs(xa)*xx(y,x)^d;
            end
        end
        res(y)=res(y)+coefs(end);
    end
end