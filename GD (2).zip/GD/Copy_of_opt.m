clc,clearvars
NL=[0 0;1 0; 0.3 1];
EL=[1 3;2 3];
BC=[0 0 0;0 0 0; 2 0 1000000];
num=100;
xx=linspace(-4,4,num);
xx=xx.';
yy=linspace(1,4,num);
yy=yy.';
disps=zeros(size(xx,1),1);
for y=1:size(yy,1)
    for x=1:size(xx,1)
        NL(3,:)=[xx(x,1),yy(y,1)];
        ENL=FEM(NL,BC,EL,2,1);
        dis=sqrt(ENL(3,9)^2+ENL(3,10)^2);
        disps(y,x)=dis;
    end
end
for y=1:size(yy,1)
    xxx(:,1,y)=xx;
    for x=1:size(xx,1)
        xxx(x,2,y)=yy(y);
    end
end
for y=1:size(yy,1)
mino(y,:)=[Inf,20];
for deg=20:20
    xxxx=xxx(:,:,y);
    xxxx=reshape(xxxx,[size(xx,1) 2]);
    [coefs,res,inps]=polynomial(2,1,deg,num,xxxx,disps,NL,BC,EL);
    figure(2);
    hold on
    errorr=0;
    for x=1:length(xx)
        errorr=errorr+abs(disps(x)-res(x));
    end
    if errorr<mino(y,1)
        mino(end+1,:)=[errorr deg];
    end
end
end
for y=1:size(yy,1)
deg=mino(y,2);

    xxxx=xxx(y,:,:);
    xxxx=reshape(xxxx,[size(xx,1) 2]);
    [coefs,res,inps]=polynomial(2,1,deg,num,xxxx,disps,NL,BC,EL);
    poli(y)=poly(deg,2,coefs);
end
for g=1:size(poli,2)
    big_coefs(:,g)=poli(g).coefs;
end
for c=1:size(big_coefs,1)
    [coefs,res,inps]=polynomial(1,1,20,num,yy,big_coefs(c,:)',NL,BC,EL);
    big_big_coefs(c,:)=coefs;
end
a=rref(inps);
figure(2);
hold on
%poli=PD(poli,1);
%r=poli.cal(xx(350));
%b=disps(350)-r*xx(350);
%kak=r*xx+b;
%disp("s "+ r);
%disp(mino(1)+" deg:"+mino(2));
%plot(xx,disps,"b-");
%plot(xx,res,"r-");
%plot(xx,kak,"g-");
asa=zeros(size(yy,1),size(xx,1));
aasa=zeros(size(yy,1),size(xx,1));
for y=1:size(yy,1)
for x=1:size(xx,1)
    for c=1:size(big_big_coefs,1)
        coefs(c)=poly(20,1,big_big_coefs(c,:)').cal(yy(y));
    end
    poli=poly(20,2,coefs);
    NL(3,:)=[xx(x,1),yy(y,1)];
    ENL=FEM(NL,BC,EL,2,1);
    dis=sqrt(ENL(3,9)^2+ENL(3,10)^2);
    asa(y,x)=poli.cal([xx(x) yy(y)]);
    aasa(y,x)=dis;
end
end
figure(3);
surf(xx,yy,asa);

figure(4);
surf(xx,yy,aasa);


