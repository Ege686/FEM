el=[0 0;-1 1];
a=atan((el(1,2)-el(2,2))/(el(1,1)-el(2,1)));
o=[1 5 7 4;5 4 7 8;8 2 4 1; 7 4 5 4];
io=inv(o);
disp(io*o);

            for el=1:size(EL,1)
                dis=0;
                if EL(el,1)==n
                    dis=distance(NL(EL(el,2),:),node);
                end
                if EL(el,2)==n
                    dis=distance(NL(EL(el,1),:),node);
                end
                if dis>3
                    proceed=false;
                end
            end