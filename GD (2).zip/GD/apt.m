clc,clearvars
element_count=2;
element_length=10/element_count;
NL=[0 0];
BC=[0 0 0 0 0 0];
EL=[];
epoch=10;
min_dis=1;
A=10^(-4);
d=7800;
Qs=[];
for i=1:element_count
    NL(i*2,:)=[NL(i*2-1,1)+element_length*cos(pi/3) NL(i*2-1,2)+element_length*sin(pi/3)];%+1-2*rand(2,1).';
    BC(i*2,:)=[2 0 0 0 0 0];
    NL(i*2+1,:)=[NL(i*2-1,1)+element_length 0];
    BC(i*2+1,:)=[2 0 0 1 0 0];
    if i==element_count
        BC(i*2+1,:)=[0 0 0 1 0 0];
    end
    if i*2+1==(element_count*2+1)/2+0.5
        BC(i*2+1,:)=[2 0 -100000 1 0 0];
    end
    EL=[EL;i*2-1 i*2];
    EL=[EL;i*2-1 i*2+1];
    EL=[EL;i*2 i*2+1];
end
kak=(element_count*2+1)/2+0.5;
for i=1:element_count-1
    EL=[EL;i*2 i*2+2];
    if i<element_count-1
        %EL=[EL;i*2 i*2+3];
    end
end
    [ENL,K]=FEM(NL,BC,EL,2,1);
    len=0;
        for e=1:size(EL,1)
            len=len+sqrt((ENL(EL(e,1),1)-ENL(EL(e,2),1))^2+(ENL(EL(e,1),2)-ENL(EL(e,2),2))^2);
        end
        Q=sqrt(ENL(kak,9)^2+ENL(kak,10)^2)*len*A*d;
    disp(Q);

lr=4*10^(-34);
max_displace=0.5;
[ENL,K,DOFs]=FEM(NL,BC,EL,1,3);
for ep=1:500
    if ep<500
        [ENL,K,DOFs]=FEM(NL,BC,EL,2,1);
    else
        [ENL,K,DOFs]=FEM(NL,BC,EL,1,1);
    end
xlim([-0.5 10.5]);
ylim([-4 7]);
    hold off;
    F=zeros(size(ENL,1)*2,1);
    for n=1:size(ENL,1)
        for dim=1:2
            F((n-1)*2+dim,1)=ENL(n,10+dim);
        end
    end
    len=0;
        for e=1:size(EL,1)
            len=len+sqrt((ENL(EL(e,1),1)-ENL(EL(e,2),1))^2+(ENL(EL(e,1),2)-ENL(EL(e,2),2))^2);
        end
        Q=sqrt(ENL(kak,9)^2+ENL(kak,10)^2)*len*A*d;
        %disp("aak "+sqrt(ENL(kak,9)^2+ENL(kak,10)^2));
    for n=1:size(NL,1)
        if BC(n,1)==2
            dN=dMSE(ENL,EL,n,kak,1,Q,K,F,len,DOFs,d,A);
            dx=lr*dN;
            if abs(dx)>max_displace
                dx=dx/abs(dx)*max_displace;
            end
            dNN=dMSE(ENL,EL,n,kak,2,Q,K,F,len,DOFs,d,A);
            dy=lr*dNN;
            %disp(dN);
            if abs(dy)>max_displace
                dy=dy/abs(dy)*max_displace;
            end
            node=[NL(n,1)-dx,NL(n,2)-dy];
            proceed=true;
            for nodee=1:size(NL,1)
               if nodee~=n
                  dis=distance(NL(nodee,:),node);
                  if dis<min_dis
                      proceed=false;
                      break;
                  end
               end
            end
            %disp(dN+" "+" "+dNN+" "+n);
            if proceed
                NL(n,1)=NL(n,1)-dx;
                NL(n,2)=NL(n,2)-dy;
            end
        end
    end
Qs(end+1)=Q;
%disp(Q);
end
[ENL,K]=FEM(NL,BC,EL,1,1);
disp(Q);

xlim([-0.5 10.5]);
ylim([-4 7]);
figure(2)
plot([1:500],Qs,"b-");
xlabel("epochs");
ylabel("objective function value");
function length=distance(a,b)
    length=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2);
end