function dn = dMSE(ENL,EL,i,k,v,Q,K,F,W,DOFs,p,A)
    el=[];
    u=sqrt(ENL(k,9)^2+ENL(k,10)^2);
    for e=1:size(EL,1)
        if EL(e,1)==i||EL(e,2)==i
            el(end+1,:)=EL(e,:);
        end
    end
    dn=0;
    for e=1:size(el,1)
        dM=chain.dMSE(Q);
        dW=chain.dW(p,A);
        dL=chain.dL(el(e,:),ENL,i,v);
        d=0;
        for vk=1:2
            dudL=chain.dudL(K,el(e,:),k,ENL,F,vk,i,DOFs);
            duda=chain.duda(K,el(e,:),k,ENL,F,vk,i,DOFs);
            da=chain.da(ENL,el(e,:),i,v);
            dudu=chain.dudu(ENL,k,vk,u);
            d=d+dudu*(dudL*dL+duda*da);
        end
        d=d*W;
        dn=dn+dM*(dW*dL*u+d);
    end
end