coefs=[];
results=[2; 8; 5];
inputs=[2 5 1; 6 7 1; 5 3 1];
coefs=inputs\results;
disp(coefs(1,1)+"x"+"+"+coefs(2,1)+"y"+ " "+coefs(3,1));
r=linspace(1,10,8);
disp(ones(3,3))