classdef poly
    properties
        degree,dim,coefs
    end
    methods
        function obj=poly(degree,dim,coefs)
            obj.degree=degree:-1:1;
            obj.dim=dim;
            obj.coefs=coefs;
        end
        function r=cal(obj,x)
            r=0;
            for xx=1:obj.dim
                for d=1:size(obj.degree,2)
                    cef=1;
                for e=1:obj.dim
                    if e~=xx
                        cef=cef*1;
                    end
                end
                    r=r+cef*obj.coefs((xx-1)*size(obj.degree,2)+d)*(x(1,xx)^obj.degree(d));
                    v=obj.coefs((xx-1)*size(obj.degree,2)+d);
                    %disp(obj.degree(d)+" "+x(1,xx)+" "+v+" "+r);
                end
            end
            r=r+obj.coefs(end,1);
        end
    end
end    