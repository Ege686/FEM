clc,clearvars
ENL=[];
ENLL=[];
NoC=2;
changable_nodeN=size(ENL,1)-NoC;
start_stepL=0.8;
last_stepL=0.03;
stepA=5;
epoch=200;
element_count=10;
element_length=10/element_count;
NL=[0 0];
BC=[0 0 0 0 0 0];
EL=[];
k=log(last_stepL+1-start_stepL)/(-epoch);
axis([-1 (1+element_count)*element_length+1 -4 4]);
max_of_bot=0.5;
ELL=[];
NLL=[];
min_dis=0.5;

for i=1:element_count
    NL(i*2,:)=[NL(i*2-1,1)+element_length*cos(pi/3) NL(i*2-1,2)+element_length*sin(pi/3)];
    BC(i*2,:)=[2 0 0 0 0 0];
    NL(i*2+1,:)=[NL(i*2-1,1)+element_length 0];
    BC(i*2+1,:)=[2 0 0 1 0 0];
    if i==element_count
        BC(i*2+1,:)=[0 0 0 1 0 0];
    end
    if i*2+1==(element_count*2+1)/2+0.5
        BC(i*2+1,:)=[2 0 -100000 1 0 0];
    end
    EL=[EL;i*2-1 i*2];
    EL=[EL;i*2-1 i*2+1];
    EL=[EL;i*2 i*2+1];
end
for i=1:element_count-1
    EL=[EL;i*2 i*2+2];
    if i<element_count-1
        %EL=[EL;i*2 i*2+3];
    end
end
startNL=NL;
finale=[];
ENL=FEM(NL,BC,EL,2,1);
drawnow;
ali=0;
javili=0;
[space,BC]=place(NL,BC,min_dis);
tic;
for e=1:epoch
    if mod(e,30)==0
        %ELL=EL;
        %NLL=NL;
        %[NL,BC,EL]=del(NL,BC,EL,min_dis);
    end
    stepL=exp(k*(-e))-1+start_stepL;
    %stepL=0.1;
    %cla;
    ENL=FEM(NL,BC,EL,0);
    tot=B(ENL,W(L(NL,EL)),element_count);
    badness=[tot,0,0];
    lagranj=NL;
    san_sebastian=BC;
    sir_charles=space;
    for n=1:size(ENL,1)
        if ENL(n,3)~=-1 && ENL(n,4)~=-1
            total_baddness=[];
            for a=0:stepA:360-stepA
                if ENL(n,3)~=-1
                    NL(n,1)=NL(n,1)+stepL*cosd(a);
                end
                if ENL(n,4)~=-1
                    NL(n,2)=NL(n,2)+stepL*sind(a);
                end
                [proceed,space,BC] = check(n,space,NL,BC,min_dis);
                %for nodee=1:size(NL,1)
                 %  if nodee~=n
                  %    dis=distance(NL(n,:),NL(nodee,:));
                   %     if dis<min_dis&&n~=11
                    %        proceed=false;
                     %       break;
                      %  end
                   % end
                %end
                if proceed
                tot_len=0;
                for el=1:size(EL,1)
                    if BC(n,4)==1
                        dis=distance(NL(n,:),startNL(n,:));
                        p=abs((element_count*2+1)/2+0.5-n);
                        cont=max_of_bot-max_of_bot/(element_count*2+1)*2*p;
                        if dis>cont
                            proceed=false;
                            break;
                        end
                    end
                    if EL(el,1)==n|| EL(el,2)==n
                        length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
                        tot_len=tot_len+length;
                        if length>3
                            proceed=false;
                            break;
                        end
                    end
                end
                end
                if proceed
                    ENL=FEM(NL,BC,EL,0);
                    for el=1:size(EL,1)
                        if EL(el,1)~=n&& EL(el,2)~=n
                            length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
                            tot_len=tot_len+length;
                        end
                    end
                    total_b=[0,a,n];
                    weight=W(tot_len);
                    total_b(1)=B(ENL,weight,element_count);
                    if size(total_baddness,1)~=0
                        %disp(total_stress(1)+" "+total_baddness(1));
                        if total_b(1)<total_baddness(1,1)
                            total_baddness=[total_b;total_baddness];
                        else
                            total_baddness=[total_baddness;total_b];
                        end
                    else
                        total_baddness=total_b;
                    end
                end
                NL=lagranj;
                BC=san_sebastian;
                space=sir_charles;
            end
            if size(total_baddness,1)~=0
                if total_baddness(1,1)<badness(1,1)
                    badness=[total_baddness(1,:);badness];
                else
                    badness=[badness;total_baddness(1,:)];
                end
            end
        end
    end
    if badness(1,3)~=0
        nod=badness(1,3);
        NL(nod,1)=lagranj(nod,1)+stepL*cosd(badness(1,2));
        NL(nod,2)=lagranj(nod,2)+stepL*sind(badness(1,2));
        [space,BC]=replace(nod,space,NL,BC,min_dis);
        finale=[badness(1,1);finale];
    else
        NL=lagranj;
        BC=san_sebastian;
        space=sir_charles;
    end
end
ENL=FEM(NL,BC,EL,1,2);
ao=toc;
disp("a "+ao);
axis([-1 (1+element_count)*element_length+1 -4 4]);
for n=1:size(NL,1)
    [proceed,space,BC]=check(n,space,NL,BC,min_dis);
    if ~proceed
        disp("or");
    end
end
function length=distance(a,b)
    length=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2);
end

function l=L(NL,EL)
    tot_len=0;
    for el=1:size(EL,1)
        length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
        tot_len=tot_len+length;
    end
    l=tot_len;
end
function w=W(len)
    
    w=len*1*10^(-4)*8000;
end
function b=B(ENL,wei,element_count)
    b=sqrt(ENL((element_count*2+1)/2+0.5,9)^2+ENL((element_count*2+1)/2+0.5,10)^2)*wei;
end
function [space,BC]=place(NL,BC,min_dis)
    space=zeros(30/(min_dis/2)+1,30/(min_dis/2)+1);
    for n=1:size(NL,1)
        x=floor(NL(n,1)/(min_dis/2));
        y=floor(NL(n,2)/(min_dis/2));
        x=x+floor(size(space,1)/2)+1;
        y=y+floor(size(space,2)/2)+1;
        space(x,y)=space(x,y)+1;
        BC(n,5)=x;
        BC(n,6)=y;
    end
end
function [present,spacee,BCC]=check(n,space,NL,BC,min_dis)
    present=false;
    spacee=space;
    BCC=BC;
    x=BC(n,5);
    y=BC(n,6);
    xx=floor(NL(n,1)/(min_dis/2));
    xx=xx+floor(size(space,1)/2)+1;
    yy=floor(NL(n,2)/(min_dis/2));
    yy=yy+floor(size(space,2)/2)+1;
    space(x,y)=space(x,y)-1;
    space(xx,yy)=space(xx,yy)+1;
    BC(n,5)=xx;
    BC(n,6)=yy;
    for X=-1:1
        for Y=-1:1
            if xx+X<=size(space,1)&&yy+Y<=size(space,2)&&xx+X>0&&yy+Y>0
                if X~=0||Y~=0
                    if space(xx+X,yy+Y)>0
                        present=true;
                        break
                    end
                else    
                    if space(xx+X,yy+Y)>1
                        present=true;
                        break
                    end
                end
            end
        end
        if present
            break
        end
    end
    if ~present
        BCC=BC;
        spacee=space;
    end
    present=~present;
end
function [spacee,BCC]=replace(n,space,NL,BC,min_dis)
    x=BC(n,5);
    y=BC(n,6);
    xx=floor(NL(n,1)/(min_dis/2));
    xx=xx+floor(size(space,1)/2)+1;
    yy=floor(NL(n,2)/(min_dis/2));
    yy=yy+floor(size(space,2)/2)+1;
    space(x,y)=space(x,y)-1;
    space(xx,yy)=space(xx,yy)+1;
    BC(n,5)=xx;
    BC(n,6)=yy;
    spacee=space;
    BCC=BC;
end