%%% PRE-PROCESS %%%
function [ENL,K,DOFs] = FEM(NL,BC,EL,hidden,fig)
%clc,clearvars
format long

A= 1*10^(-4);
E= 210*10^9;

%PD : Problem Dimension
%NPE : Number of Nodes per Element

%NoN : Number of Nodes
%NoE : Number of Elements

%NL : Node List [NoN X PD] (Coordinates)
%EL : Element List [ NoE x NPE ]

%ENL : Extended Node List [ NoN x (6xPD) ]
%DOFs : Degrees of Freedom
%DOCs : Degrees of Constraint


 [ENL, DOFs, DOCs] = assign_BCs(NL,BC);

K = assemble_stiffness(ENL,EL,NL,E,A);

Fp = assemble_forces(ENL,NL);
Up = assemble_displacements(ENL,NL);

Kpu = K(1:DOFs,1:DOFs);
Kpp = K(1:DOFs,DOFs+1:DOFs+DOCs);
Kuu = K(DOFs+1:DOCs+DOFs,1:DOFs);
Kup = K(DOFs+1:DOCs+DOFs,DOFs+1:DOCs+DOFs);

F = Fp - Kpp * Up;

Uu = inv(Kpu)*F;

Fu =Kuu*Uu + Kup*Up;

ENL = update_nodes(ENL,Uu,NL,Fu);


Node_flag ='off'; %off
Element_flag = 'off'; %off
mag = 2;
if hidden==1
    post_process(NL,EL,ENL,E,Node_flag,Element_flag,mag,fig);

end











        


 

   




