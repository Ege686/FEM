clc,clearvars
NL=[0 0;1 0; 0.3 1];
EL=[1 3;2 3];
BC=[0 0 0;0 0 0; 2 0 1000000];
num=100;
xx=linspace(0.5,0.5,num);
xx=xx.';
yy=linspace(1,1,num);
yy=yy.';
disps=zeros(size(xx,1),1);
    for x=1:1
        r=randi([1 100]);
        rr=randi([1 100]);
        xxx(x,:)=[xx(x,1) yy(x,1)];
        NL(3,:)=[xx(x,1),yy(x,1)];
        ENL=FEM(NL,BC,EL,1,1);
        len=0;
        for e=1:size(EL,1)
            len=len+sqrt((ENL(EL(e,1),1)-ENL(EL(e,2),1))^2+(ENL(EL(e,1),2)-ENL(EL(e,2),2))^2);
        end
        dis=sqrt(ENL(3,9)^2+ENL(3,10)^2)*len;
        disps(x,1)=dis;
    end
for deg=1:20
    mino=[Inf,20];
    [coefs,res,inps]=polynomial(2,1,deg,num,xxx,disps,NL,BC,EL);
    errorr=0;
    for x=1:length(xx)
        errorr=errorr+abs(disps(x)-res(x));
    end
    if errorr<mino(1)
        mino=[errorr deg];
    end
end
deg=mino(2);
[coefs,res,inps]=polynomial(2,1,deg,num,xxx,disps,NL,BC,EL);
poli=poly(deg,2,coefs);
for x=1:size(xxx,1)
    res(x)=poli.cal([xxx(x,1) xxx(x,2)]);
end
a=rref(inps);
hold on
%poli=PD(poli,1);
%r=poli.cal(xx(350));
%b=disps(350)-r*xx(350);
%kak=r*xx+b;
%disp("s "+ r);
disp(mino(1)+" deg:"+mino(2));
figure(1);
plot(xx,disps,"b-");
plot(xx,res,"r-");
%plot(xx,kak,"g-");
asa=zeros(size(yy,1),size(xx,1));
aasa=zeros(size(yy,1),size(xx,1));
for y=1:size(yy,1)
for x=1:size(xx,1)
    NL(3,:)=[xx(x,1),yy(y,1)];
    ENL=FEM(NL,BC,EL,2,1);len=0;
        for e=1:size(EL,1)
            len=len+sqrt((ENL(EL(e,1),1)-ENL(EL(e,2),1))^2+(ENL(EL(e,1),2)-ENL(EL(e,2),2))^2);
        end
    dis=sqrt(ENL(3,9)^2+ENL(3,10)^2)*len;
    asa(y,x)=poli.cal([xx(x,1) yy(y,1)]);
    aasa(y,x)=dis;
end
end
figure(3);
colormap("jet");
surf(xx,yy,asa);

figure(4);
colormap("jet");
surf(xx,yy,aasa);


