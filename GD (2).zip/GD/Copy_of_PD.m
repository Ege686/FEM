function poly = PD(poly,x)
    s=(x-1)*size(poly.degree,2)+1;
    for c=1:size(poly.degree,2)
        poly.coefs(c+s-1,1)=poly.coefs(c+s-1,1)*poly.degree(c);
    end
    poly.coefs=poly.coefs(s:s+size(poly.degree,2)-1,:);
    poly.dim=1;
    poly.degree=(size(poly.degree,2)-1):-1:1;
end