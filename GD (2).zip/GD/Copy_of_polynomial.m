function [coefs,res,inps]=polynomial(PD,NC,deg,num,xx,disps,NL,BC,EL)
    dim=PD*NC;
    deg=deg*dim;
    inps=ones(deg+1, deg+1);
    inpss=ones(deg+1, size(xx,2));
    r=linspace(1,num,deg+1);
    reso=zeros(deg+1,1);
    for i=1:deg+1
        inpss(i,1:end)=[xx(floor(r(i)),1),xx(floor(r(i)),2)];
    end
    for y=1:deg+1
        for x=1:size(xx,2)
            for d=1:deg/dim+1
                xa=deg/dim*(x-1)+d;
                inps(y,xa)=inpss(y,x)^(deg/dim-d+1);
            end
        end
        bos=inps;
        %bos=[vec(1,:)];
        %for u=2:size(vec,1)
        %    c=zeros(1,size(vec,2));
        %    for uu=1:u-1
        %        c=c+bos(uu,:).*vec(u,:);
        %    end
        %    bos=[bos;vec(u,:)-c];
        %end
        reso(y)=disps(floor(r(y)),1);
    end
    %bos([2,end],:)=bos([end,2],:);
    %reso([2,end],:)=reso([end,2],:);
    %inps([2,end],:)=inps([end,2],:);
    bos=rref(bos);
    coefs=ones(deg+1,1);
    rr=deg+1;
    for r=size(bos,1):-1:2
        if bos(r,:)==zeros(1,deg+1)
            rr=r;
        else
            break;
        end
    end
    inpsi=inps;
    resoi=reso;
    while rr<size(inps,1)
    for y=1:size(inps,1)
        for x=1:size(inps,2)
            if x~=rr&&y~=rr
                inps(y,x)=inps(y,x)-inps(rr,x)*inps(y,rr)/inps(rr,rr);
            end
        end
        reso(y)=reso(y)-reso(rr)*inps(y,rr)/inps(rr,rr);
    end
    inps=[inps(1:rr-1,:);inps(rr+1:end,:)];
    inps=[inps(:,1:rr-1),inps(:,rr+1:end)];
    reso=[reso(1:rr-1,1);reso(rr+1:end,1)];
    bos=inps;
    bos=rref(bos);
    coefs=ones(deg+1,1);
    rr=size(inps,1);
    for r=size(bos,1):-1:2
        if bos(r,:)==zeros(1,size(bos,2))
            rr=r;
        else
            break;
        end
    end
    end
    %resoo=reso(1:rr,:)-inps(1:rr,rr+1:end)*coefs(rr+1:end,:);
    coefs(1:rr,1)=inps\reso;
    resoi(rr+1:end,1)=resoi(rr+1:end,1)-inpsi(rr+1:end,1:rr)*coefs(1:rr,1);
    coefs(rr+1:end,1)=inpsi(rr+1:end,rr+1:end)\resoi(rr+1:end,1);
    %coefss=coefs;
    %resoo=reso(rr+1:end,:)-inps(rr+1:end,1:rr)*coefs(1:rr,1);
    %coefss(rr+1:end,1)=inps(rr+1:end,rr+1:end)\resoo;
    res=zeros(1,num);
    for y=1:size(xx,1)
        for x=1:size(xx,2)
            for d=deg/dim:-1:1
                xa=deg/dim*(x-1)+(deg/dim-d+1);
                    res(y)=res(y)+coefs(xa)*xx(y,x).^d;
            end
        end
        res(y)=res(y)+coefs(end);
    end
end