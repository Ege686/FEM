function [coefs,res,inps]=polynomial(PD,NC,deg,num,xx,disps,NL,BC,EL)
    dim=PD*NC;
    deg=deg*dim;
    inps=ones(deg+1, deg+1);
    inpss=ones(deg+1, size(xx,2));
    r=linspace(1,num,deg+1);
    reso=zeros(deg+1,1);
    for i=1:deg+1
        inpss(i,1:end)=[xx(floor(r(i)),1),xx(floor(r(i)),2)];
    end
    
    for y=1:deg+1
        for x=1:size(xx,2)
            for d=1:deg/dim+1
                xa=deg/dim*(x-1)+d;
                inps(y,xa)=inpss(y,x)^(deg/dim-d+1);
            end
        end
        bos=inps;
        %bos=[vec(1,:)];
        %for u=2:size(vec,1)
        %    c=zeros(1,size(vec,2));
        %    for uu=1:u-1
        %        c=c+bos(uu,:).*vec(u,:);
        %    end
        %    bos=[bos;vec(u,:)-c];
        %end
        reso(y)=disps(floor(r(y)),1);
    end
    bos([2,end],:)=bos([end,2],:);
    reso([2,end],:)=reso([end,2],:);
    inps([2,end],:)=inps([end,2],:);
    bos=rref(bos);
    coefs=ones(deg+1,1);
    rr=deg+1;
    for r=size(bos,1):-1:2
        if bos(r,:)==zeros(1,deg+1)
            coefs(r,1)=1;
            rr=r-1;
        else
            break;
        end
    end
    reso=reso(1:rr,:)-inps(1:rr,rr+1:end)*coefs(rr+1:end,:);
    coefs(1:rr,1)=inps(1:rr,1:rr)\reso;
    res=zeros(1,num);
    for y=1:size(xx,1)
        for x=1:size(xx,2)
            for d=deg/dim:-1:1
                xa=deg/dim*(x-1)+(deg/dim-d+1);
                res(y)=res(y)+coefs(xa)*xx(y,x).^d;
            end
        end
        res(y)=res(y)+coefs(end);
    end
end