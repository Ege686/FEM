classdef trussMember <handle
    properties
        x1,y1,l,x2,y2,x,y,teta,w,m,a,I,speedX,speedY,accelX,accelY,forceX,forceY,mass,p1,p2,line,k,g,fixed,ffixed
    end
    methods
        function obj=ball(x,y,l)
            obj.g=-5;
            obj.k=100;
            obj.mass=1;
            obj.fixed=true;
            obj.ffixed=false;

            obj.x1=x;
            obj.y1=y;
            obj.l=l;

            obj.x2=obj.x1+l;
            obj.y2=obj.y1;

            obj.x=(obj.x1+obj.x2)/2;
            obj.y=(obj.y1+obj.y2)/2;

            obj.teta=0;
            obj.a=0;
            obj.w=0;
            obj.m=0;
            obj.I=1/12*obj.mass*obj.l^2;

            obj.speedX=0;
            obj.speedY=0;

            obj.accelX=0;
            obj.accelY=obj.g*obj.mass/obj.k;

            obj.forceX=0;
            obj.forceY=0;
            
            obj.p1=plot(obj.x1,obj.y1,"bo");
            hold on;
            obj.p2=plot(obj.x2,obj.y2,"bo");
            obj.line=plot([obj.x1 obj.x2],[obj.y1 obj.y2],"b-");
        end
        function update(obj)
            set(obj.p1,"xData",obj.x1);
            set(obj.p1,"yData",obj.y1);

            set(obj.p2,"xData",obj.x2);
            set(obj.p2,"yData",obj.y2);

            set(obj.line,"xData",[obj.x1 obj.x2]);
            set(obj.line,"yData",[obj.y1 obj.y2]);
        end
        function physics(obj)
            obj.accelX=obj.forceX/obj.mass;
            obj.accelY=obj.forceY/obj.mass;
            obj.a=obj.m/obj.I;
            
            obj.speedX=obj.speedX+obj.accelX;
            obj.speedY=obj.speedY+obj.accelY;
            obj.w=obj.w+obj.a/10;

            obj.x=obj.x+obj.speedX;
            obj.y=obj.y+obj.speedY;
            obj.teta=obj.teta+obj.w;

            obj.x1=obj.x-obj.l/2*cos(obj.teta);
            obj.x2=obj.x+obj.l/2*cos(obj.teta);

            obj.y1=obj.y-obj.l/2*sin(obj.teta);
            obj.y2=obj.y+obj.l/2*sin(obj.teta);

            obj.update;
        end
        function force(obj,F)
            %F=[F;0 0 0];
            for f=1:size(F,1)
                %if f ==size(F,1)
                 %   F(size(F,1),1)=-obj.forceX;
                  %  F(size(F,1),2)=-obj.forceY;
                %end
                obj.forceX=obj.forceX+F(f,1);
                obj.forceY=obj.forceY+F(f,2);
                
                if F(f,3)~=0.5
                    signX=-(obj.x1-obj.x2)/abs(obj.x1-obj.x2);
                    signY=-(obj.y1-obj.y2)/abs(obj.y1-obj.y2);
                    if isnan(signX)
                        signX=1;
                    end
                    if isnan(signY)
                        signY=1;
                    end
                    d=F(f,3)*obj.l;
                    poi=[signX*d*cos(obj.teta)+obj.x1 signY*d*sin(obj.teta)+obj.y1];
                    dis=[poi(1)-obj.x poi(2)-obj.y];
                    obj.m=obj.m-dis(2)*F(f,1)+dis(1)*F(f,2);
                end
            end
            obj.physics;
            obj.forceX=0;
            obj.forceY=obj.g*obj.mass/obj.k;
            obj.m=0;
        end
    end
end