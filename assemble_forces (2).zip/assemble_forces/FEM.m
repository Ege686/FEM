%%% PRE-PROCESS %%%
function [ENL] = FEM(NL,BC,EL,hidden,hoha,stress,fig,default_A,default_E,figure,optimize,mag)
%clc,clearvars
format long


%PD : Problem Dimension
%NPE : Number of Nodes per Element

%NoN : Number of Nodes
%NoE : Number of Elements

%NL : Node List [NoN X PD] (Coordinates)
%EL : Element List [ NoE x NPE ]

%ENL : Extended Node List [ NoN x (6xPD) ]
%DOFs : Degrees of Freedom
%DOCs : Degrees of Constraint


 [ENL, DOFs, DOCs] = assign_BCs(NL,BC);

K = assemble_stiffness(ENL,EL,NL,default_E,default_A);

Fp = assemble_forces(ENL,NL);
Up = assemble_displacements(ENL,NL);

Kpu = K(1:DOFs,1:DOFs);
Kpp = K(1:DOFs,DOFs+1:DOFs+DOCs);
Kuu = K(DOFs+1:DOCs+DOFs,1:DOFs);
Kup = K(DOFs+1:DOCs+DOFs,DOFs+1:DOCs+DOFs);

F = Fp - Kpp * Up;

Uu = inv(Kpu)*F;

Fu =Kuu*Uu + Kup*Up;

ENL = update_nodes(ENL,Uu,NL,Fu);


Node_flag ='on'; %off
Element_flag = 'on'; %off
if hidden==1
    if optimize
        most_process(NL,EL,ENL,default_E,Node_flag,Element_flag,mag,hoha,stress,fig,figure);
    else
        post_process(NL,EL,ENL,default_E,Node_flag,Element_flag,mag,hoha,stress,fig,figure);
    end
elseif hidden==2
    HiddenPostProcess(NL,EL);
end
end











        


 

   




