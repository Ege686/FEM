function [NL,EL,BC,ENL,finale]=draw_it(figuree1,element_count,A,E,optimize,finale,n,mag,stress)
element_length=10/element_count;
NL=[0 0];
BC=[-1 -1 0 0 0];
EL=[];
figuree1.XLim=[-1 (1+element_count)*element_length+1];
figuree1.YLim=[-4 4];
for i=1:element_count
    NL(i*2,:)=[NL(i*2-1,1)+element_length*cos(pi/3) NL(i*2-1,2)+element_length*sin(pi/3)];
    BC(i*2,:)=[1 1 0 0 0];
    NL(i*2+1,:)=[NL(i*2-1,1)+element_length 0];
    BC(i*2+1,:)=[1 1 0 0 1];
    if i==element_count
        BC(i*2+1,:)=[-1 -1 0 0 1];
    end
    if i*2+1==(element_count*2+1)/2+0.5
        BC(i*2+1,:)=[1 1 0 -100000 1];
    end
    EL=[EL;i*2-1 i*2 E A];
    EL=[EL;i*2-1 i*2+1 E A];
    EL=[EL;i*2 i*2+1 E A];
end
for i=1:element_count-1
    EL=[EL;i*2 i*2+2 E A];
    if i<element_count-1
        %EL=[EL;i*2 i*2+5 E A];
    end
end
startNL=NL;
ENL=FEM(NL,BC(:,1:4),EL,1,jet,stress,1,EL(:,4),EL(:,3),figuree1,optimize,mag);
drawnow;

tot_lenn=L(NL,EL);
weight=W(tot_lenn);
fin=[n,0,weight,0];
[fin(2),fin(4)]=B(ENL,weight,element_count);
finale=[fin;finale];
function length=distance(a,b)
    length=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2);
end
function l=L(NL,EL)
    tot_len=0;
    for el=1:size(EL,1)
        length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
        tot_len=tot_len+length;
    end
    l=tot_len;
end
function w=W(len)
    w=len*1*10^(-2)*8000;
end
function [b,d]=B(ENL,wei,element_count)
    d=sqrt(ENL((element_count*2+1)/2+0.5,9)^2+ENL((element_count*2+1)/2+0.5,10)^2);
    b=d*wei;
end
end