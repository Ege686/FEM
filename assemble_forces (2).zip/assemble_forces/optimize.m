function [finale]=optimize(NL,EL,BC,ENL,figuree1,stepA,epoch,element_count,A,E,periods,optimize,start_stepL,last_stepL,min_dis,mag,stress)
element_length=10/element_count;
k=log(last_stepL+1-start_stepL)/(-epoch);
figuree1.XLim=[-1 (1+element_count)*element_length+1];
figuree1.YLim=[-4 4];
max_of_bot=0.7;
finale=[];
startNL=NL;
for e=1:epoch
    if mod(e,periods)==0
        ENL=FEM(NL,BC(:,1:4),EL,1,jet,stress,1,A,E,figuree1,optimize,mag);
        drawnow;
    end

    ENL=FEM(NL,BC(:,1:4),EL,0,jet,true,1,A,E,figuree1,optimize);
    stepL=exp(k*(-e))-1+start_stepL;
    w=W(L(NL,EL));
    [tot,d]=B(ENL,w,element_count);
    badness=[tot,0,0,w,d];
    lagranj=NL;
    for n=1:round(size(ENL,1)/2)
        if ENL(n,3)~=-1 && ENL(n,4)~=-1
            total_baddness=[];
            for a=0:stepA:360-stepA
                if ENL(n,3)~=-1
                    NL(n,1)=NL(n,1)+stepL*cosd(a);
                    if n ~=(element_count*2+1)/2+0.5
                        o_n=size(NL,1)+1-n;
                        NL(o_n,1)=NL(o_n,1)+stepL*cosd(a+90);
                    end
                end
                if ENL(n,4)~=-1
                    NL(n,2)=NL(n,2)+stepL*sind(a);
                    if n ~=(element_count*2+1)/2+0.5
                        o_n=size(NL,1)+1-n;
                        NL(o_n,2)=NL(o_n,2)+stepL*sind(a);
                    end
                end
                proceed=true;
                if n==(element_count*2+1)/2+0.5
                    if NL(n,2)-lagranj(n,2)<0
                        proceed=false;
                    end
                end
                for nodee=1:size(NL,1)
                   if nodee~=n
                      dis=distance(NL(n,:),NL(nodee,:));
                        if dis<min_dis
                            proceed=false;
                            break;
                        end
                    end
                end
                if proceed
                tot_len=0;
                for el=1:size(EL,1)
                    if BC(n,5)==1
                        dis=distance(NL(n,:),startNL(n,:));
                        p=abs((element_count*2+1)/2+0.5-n);
                        cont=max_of_bot-max_of_bot/(element_count*2+1)*2*p;
                        if dis>cont
                            proceed=false;
                            break;
                        end
                    end
                    if EL(el,1)==n|| EL(el,2)==n
                        length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
                        tot_len=tot_len+length;
                        if length>3
                            proceed=false;
                            break;
                        end
                    end
                end
                end
                if proceed
                    ENL=FEM(NL,BC(:,1:4),EL,0,jet,true,1,A,E,figuree1,optimize);
                    for el=1:size(EL,1)
                        if EL(el,1)~=n&& EL(el,2)~=n
                            length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
                            tot_len=tot_len+length;
                        end
                    end
                    weight=W(tot_len);
                    total_b=[0,a,n,weight,0];
                    [total_b(1),total_b(5)]=B(ENL,weight,element_count);
                    if size(total_baddness,1)~=0
                        if total_b(1)<total_baddness(1,1)
                            total_baddness=[total_b;total_baddness];
                        else
                            total_baddness=[total_baddness;total_b];
                        end
                    else
                        total_baddness=total_b;
                    end
                end
                NL=lagranj;
            end
            if size(total_baddness,1)~=0
                if total_baddness(1,1)<badness(1,1)
                    disp(total_baddness(1,1)+" "+badness(1,1));
                    badness=[total_baddness(1,:);badness];
                else
                    badness=[badness;total_baddness(1,:)];
                end
            end
        end
    end
    if badness(1,3)~=0
        nod=badness(1,3);
        disp(badness(1,1));
        NL(nod,1)=lagranj(nod,1)+stepL*cosd(badness(1,2));
        NL(nod,2)=lagranj(nod,2)+stepL*sind(badness(1,2));
        if nod ~=(element_count*2+1)/2+0.5
            o_n=size(NL,1)+1-nod;
            NL(o_n,1)=lagranj(o_n,1)-stepL*cosd(badness(1,2));
            NL(o_n,2)=lagranj(o_n,2)+stepL*sind(badness(1,2));
        end
        finale=[badness(1,[1,4,5]);finale];
    else
        NL=lagranj;
    end
end
ENL=FEM(NL,BC(:,1:4),EL,1,jet,stress,1,A,E,figuree1,optimize,mag);
axis([-1 (1+element_count)*element_length+1 -4 4]);

tot_len=L(NL,EL);
weight=W(tot_len);
fin=[0,0,0,weight,0];
[fin(1),fin(5)]=B(ENL,weight,element_count);
finale=[fin(1,[1,4,5]);finale];
function length=distance(a,b)
    length=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2);
end

function l=L(NL,EL)
    tot_len=0;
    for el=1:size(EL,1)
        length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
        tot_len=tot_len+length;
    end
    l=tot_len;
end
function w=W(len)
    
    w=len*1*0.01*8000;
end
function [b,d]=B(ENL,wei,element_count)
    d=sqrt(ENL((element_count*2+1)/2+0.5,9)^2+ENL((element_count*2+1)/2+0.5,10)^2);
    b=d*wei;
end
end