function post_process(NL, EL)
    NoN = size(NL, 1);
    NoE = size(EL, 1);
    
    %%% Draw the undeformed configuration %%%
    %axis equal
hold on
    % Plot elements
for i = 1:NoE
    figure(1)
    H = plot([NL(EL(i, 1), 1), NL(EL(i, 2), 1)], [NL(EL(i, 1), 2), NL(EL(i, 2), 2)],'LineWidth', 3, 'Color','k');
    H.Color(4)= 0.2;
end

    % Plot nodes
for i = 1:NoN
    plot(NL(i, 1), NL(i, 2), 'o', 'MarkerSize', 10, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r');
end

    % Plot elements with stress distribution




end