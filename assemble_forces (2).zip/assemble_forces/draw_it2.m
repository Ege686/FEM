function [NL,EL,BC,ENL,finale]=draw_it2(NL,EL,BC,figuree1,A,E,optimize,finale,n,mag,stress)


ENL=FEM(NL,BC(:,1:4),EL,1,jet,stress,1,A,E,figuree1,optimize,mag);
drawnow;

tot_lenn=L(NL,EL);
weight=W(tot_lenn);
fin=[n,0,weight,0];
[fin(2),fin(4)]=B(ENL,weight,n);
finale=[fin;finale];
function length=distance(a,b)
    length=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2);
end
function l=L(NL,EL)
    tot_len=0;
    for el=1:size(EL,1)
        length=distance(NL(EL(el,1),:),NL(EL(el,2),:));
        tot_len=tot_len+length;
    end
    l=tot_len;
end
function w=W(len)
    w=len*1*0.01*7800;
end
function [b,d]=B(ENL,wei,element_count)
    d=sqrt(ENL((element_count*2+1)/2+0.5,9)^2+ENL((element_count*2+1)/2+0.5,10)^2);
    b=d*wei;
end
end