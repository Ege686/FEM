
function post_process(NL, EL, ENL, default_E, Node_flag, Element_flag, mag,hoha,stress,fig,figure)
    NoN = size(NL, 1);
    NoE = size(EL, 1);

    cla(figure);
    hold(figure,"on");
    %%% Draw the undeformed configuration %%%
    %axis equal
    % Plot elements
for i = 1:NoE
    H = plot(figure,[NL(EL(i, 1), 1), NL(EL(i, 2), 1)], [NL(EL(i, 1), 2), NL(EL(i, 2), 2)],'LineWidth', 3, 'Color','k');
    H.Color(4)= 0.2;
end

    % Plot nodes
for i = 1:NoN
    plot(figure,NL(i, 1), NL(i, 2), 'o', 'MarkerSize', 10, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r');
end

    %%% Draw the deformed configuration %%%
colorMap = hoha;
colormap(colorMap);
if strcmp(stress,"Stress")
    % Plot elements with stress distribution
for i = 1:NoE
    x = [ENL(EL(i,1),1) + mag * ENL(EL(i,1),9), ENL(EL(i,2),1) + mag * ENL(EL(i,2),9)];
    y = [ENL(EL(i,1),2) + mag * ENL(EL(i,1),10), ENL(EL(i,2),2) + mag * ENL(EL(i,2),10)];
    z = zeros(size(x));
    sigma = default_E(i) * (sqrt((ENL(EL(i,1),9) - ENL(EL(i,2),9))^2 + (ENL(EL(i,1),10) - ENL(EL(i,2),10))^2) ...
        / sqrt((ENL(EL(i,1),1) - ENL(EL(i,2),1))^2 + (ENL(EL(i,1),2) - ENL(EL(i,2),2))^2));
    col = [sigma sigma];
    surface(figure,[x;x], [y;y], [z;z], [col;col], 'facecol', 'no', 'edgecol', 'interp', 'linew', 4);
end
else
for i = 1:NoE
    x = [ENL(EL(i,1),1) + mag * ENL(EL(i,1),9), ENL(EL(i,2),1) + mag * ENL(EL(i,2),9)];
    y = [ENL(EL(i,1),2) + mag * ENL(EL(i,1),10), ENL(EL(i,2),2) + mag * ENL(EL(i,2),10)];
    
    u_zero=sqrt(ENL(EL(i,1),9)^2+ENL(EL(i,1),10)^2);
    u_L=sqrt(ENL(EL(i,2),9)^2+ENL(EL(i,2),10)^2);
    L=sqrt((ENL(EL(i,1),1)-ENL(EL(i,2),1))^2+(ENL(EL(i,1),2)-ENL(EL(i,2),2))^2);
    col = [u_zero u_L];
    a=(u_L-u_zero)/L;
    z = a*x+u_zero;
    surface(figure,[x;x], [y;y], [z;z], [col;col], 'facecol', 'no', 'edgecol', 'interp', 'linew', 4);
end
end


%%% Plot Element Numbers %%%
if isequal(Element_flag, 'on')

    for i = 1:NoE
        text(figure,(ENL(EL(i,1),1) + mag * ENL(EL(i,1),9) + ENL(EL(i,2),1) + mag * ENL(EL(i,2),9)) / 2,(ENL(EL(i,1),2)+mag * ENL(EL(i,1),10)+ENL(EL(i,2),2)+mag *ENL(EL(i,2),10))/2, ...
            num2str(i),'Color','k','FontSize',16,'HorizontalAlignment','center');
    end
end

%%% Plot Nodes %%%
for i = 1:NoN
   plot(figure,ENL(i,1)+mag*ENL(i,9),ENL(i,2)+mag*ENL(i,10),'o','MarkerSize',16,'MarkerEdgeColor','k','MarkerFaceColor',[0,0.7,0.9]);
end

if isequal(Node_flag,'on')
    for i= 1:NoN

        text(figure,ENL(i,1)+mag*ENL(i,9),ENL(i,2)+mag*ENL(i,10),num2str(i),'Color','w','FontSize',12,'HorizontalAlignment','center');
    end
end

    hold(figure,"off");

end