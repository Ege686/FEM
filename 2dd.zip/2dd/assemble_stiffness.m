function [K] = assemble_stiffness(ENL, EL, NL)
% Determine sizes and parameters
    NoE = size(EL, 1);    % Number of elements
    NPE = size(EL, 2);    % Nodes per element
     
    NoN = size(NL, 1);    % Number of nodes
    PD = size(NL, 2);     % Problem dimension
    
    
    K = zeros(NoN * PD, NoN * PD);
    
    if NPE == 3
        GPE = 3;
    elseif NPE == 4
        GPE = 4;
    elseif NPE==9
        GPE=9;
    elseif NPE==8
        GPE=8;
    elseif NPE==6
        GPE=3;
    end
        
    for i = 1:NoE
        nl = EL(i, 1:NPE);  % Node list of each element
        x = zeros(NPE, PD);
        for j = 1:NPE
             
            x(j,:) = ENL(nl(j), 1:PD);
    
        end
        k = Stiffness(x,GPE);
        for r = 1:NPE %d1
            
            for p = 1:PD
    
                for q = 1:NPE %2
    
                    for s = 1:PD
    
       
                            row = ENL(nl(r), p+3*PD);  % Row index in global matrix
                            column = ENL(nl(q), s+3*PD);  % Column index in global matrix
    
                            
                            value = k((r - 1) * PD + p, (q - 1) * PD + s);
                            K(row, column) = K(row, column) + value;
    
                     end
                 end
            end
        end
    end
end