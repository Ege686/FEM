function [ENL,stress_xx,stress_xy,stress_yx,stress_yy,strain_xx,strain_xy,strain_yx,strain_yy,disp_x,disp_y,X,Y]=FEM(NL,EL,stage,fig,fig2,BC_type)

%%%%%%%PREPROCESS%%%%%%
format long


%[NL,EL] = uniform_mesh(d1,d2,p,m,element_type);

%%%%%%PROCESS%%%%%% %Expansion Shear

[ENL, DOFs, DOCs] = assign_BCs(NL, BC_type);

K = assemble_stiffness(ENL,EL,NL);

Fp = assemble_forces(ENL, NL);

Up = assemble_displacements(ENL,NL);

Kpu = K(1:DOFs, 1:DOFs);
Kpp = K(1:DOFs, DOFs+1:DOFs+DOCs);
Kuu = K(DOFs+1:DOCs+DOFs, 1:DOFs);
Kup = K(DOFs+1:DOCs+DOFs, DOFs+1:DOCs+DOFs);

F = Fp - Kpp * Up;
Uu = inv(Kpu) * F;
Fu = Kuu * Uu + Kup * Up;
ENL = update_nodes(ENL, Uu, NL, Fu);

[stress_xx,stress_xy,stress_yx,stress_yy,strain_xx,strain_xy,strain_yx,strain_yy,disp_x,disp_y,X,Y]=post_process(NL, EL, ENL,stage,fig,fig2);
end

