function runner(d1,d2,p,m, R, element_type, geometry, fig)

%[NL,EL]= uniform_mesh(d1,d2,p,m, element_type);
[NL,EL]= void_mesh(d1,d2,p,m, R, element_type, geometry);
%[NL, EL] = inclusion_mesh(d1, d2, p, m, R, geometry, element_type, inclusion_or_void);
NoN= size(NL,1);
NoE= size(EL, 1);
NPE= size(EL,2);
switch element_type
    case 'D2TR3N' % For triangular elements
        for i = 1:NoE
            % Plot the edges of the triangle
            plot(fig,[NL(EL(i,1),1), NL(EL(i,2),1)], [NL(EL(i,1),2), NL(EL(i,2),2)], 'r-'); % Red line
            hold(fig,"on");
            plot(fig,[NL(EL(i,2),1), NL(EL(i,3),1)], [NL(EL(i,2),2), NL(EL(i,3),2)], 'r-');
            plot(fig,[NL(EL(i,3),1), NL(EL(i,1),1)], [NL(EL(i,3),2), NL(EL(i,1),2)], 'r-');
            x = (NL(EL(i,1),1) + NL(EL(i,2),1) + NL(EL(i,3),1)) / 3;
            y = (NL(EL(i,1),2) + NL(EL(i,2),2) + NL(EL(i,3),2)) / 3;
            % Add the element number at the centroid of the triangle
            %text(fig,x, y, num2str(i), 'Color', 'magenta', 'FontSize', 8, 'HorizontalAlignment', 'center');
        end
     case 'D2TR6N' % For quadratic triangular elements
        for i = 1:NoE
    
            % Corner Nodes
            n1 = EL(i,1); n2 = EL(i,2); n3 = EL(i,3);
            % Mid-side Nodes
            n4 = EL(i,4); n5 = EL(i,5); n6 = EL(i,6);
            % NL(n7,1) = NL(n1,1); NL(n7,2) = NL(n3,2);
            % for i = 1 : NoN
            %     hold on;
            %     plot(NL(i,1), NL(i,2), 'o', 'MarkerSize', 10, 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'b'); % Small blue dots
            %     text(NL(i,1), NL(i,2), num2str(i), 'Color', 'w', 'FontSize', 6, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle'); % Centered white numbers
            % end
    
            % Plot edges with mid-side nodes for quadratic triangles
            plot(fig,[NL(n1,1), NL(n4,1)], [NL(n1,2), NL(n4,2)], 'r-'); % Edge n1 to n4
            hold(fig,"on");
            plot(fig,[NL(n4,1), NL(n2,1)], [NL(n4,2), NL(n2,2)], 'r-'); % Edge n4 to n2
            plot(fig,[NL(n2,1), NL(n5,1)], [NL(n2,2), NL(n5,2)], 'r-'); % Edge n2 to n5   
            plot(fig,[NL(n5,1), NL(n3,1)], [NL(n5,2), NL(n3,2)], 'r-'); % Edge n5 to n3
            plot(fig,[NL(n3,1), NL(n6,1)], [NL(n3,2), NL(n6,2)], 'r-'); % Edge n3 to n6
            plot(fig,[NL(n6,1), NL(n1,1)], [NL(n6,2), NL(n1,2)], 'r-'); % Edge n6 to n1
            %plot([NL(n7,1), NL(n1,1)], [NL(n7,2), NL(n3,2)], 'r-');
    
            % Plot mid-side nodes as red circles
            plot(fig,NL(n4,1), NL(n4,2), 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b'); % Node n4
            plot(fig,NL(n5,1), NL(n5,2), 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b'); % Node n5
            plot(fig,NL(n6,1), NL(n6,2), 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b'); % Node n6
    
            % Compute and mark element number at the centroid
            x_centroid = (NL(n1,1) + NL(n2,1) + NL(n3,1)) / 3; % X-coordinate of centroid
            y_centroid = (NL(n1,2) + NL(n2,2) + NL(n3,2)) / 3; % Y-coordinate of centroid
            %text(fig,x_centroid, y_centroid, num2str(i), 'Color', 'magenta', ...
                %'FontSize', 8, 'HorizontalAlignment', 'center');
            
        end
    case 'D2QU4N' % For quadrilateral elements
        for i = 1:NoE
            % Extract node indices for the current quadrilateral element
            n1 = EL(i,1);
            n2 = EL(i,2);
            n3 = EL(i,3);
            n4 = EL(i,4);
            
            % Plot the four edges of the quadrilateral element
            plot(fig,[NL(n1,1), NL(n2,1)], [NL(n1,2), NL(n2,2)], 'r-'); % Red line
            hold(fig,"on");
            plot(fig,[NL(n2,1), NL(n3,1)], [NL(n2,2), NL(n3,2)], 'r-');
            plot(fig,[NL(n3,1), NL(n4,1)], [NL(n3,2), NL(n4,2)], 'r-');
            plot(fig,[NL(n4,1), NL(n1,1)], [NL(n4,2), NL(n1,2)], 'r-');


            % Find the centroid of the quadrilateral for labeling
            xm = (NL(n1,1) + NL(n2,1) + NL(n3,1) + NL(n4,1)) / 4;
            ym = (NL(n1,2) + NL(n2,2) + NL(n3,2) + NL(n4,2)) / 4;
            %text(fig,xm, ym, num2str(i), 'Color', 'magenta', 'FontSize', 8, 'HorizontalAlignment', 'center');
        end
    case 'D2QU8N' % For quadrilateral elements
        for i = 1:NoE
            % Extract node indices for the current quadrilateral element
            n1 = EL(i,1);
            n2 = EL(i,2);
            n3 = EL(i,3);
            n4 = EL(i,4);
            n5 = EL(i,5);
            n6 = EL(i,6);
            n7 = EL(i,7);
            n8 = EL(i,8);
            
            % Plot the four edges of the quadrilateral element
            plot(fig,[NL(n1,1), NL(n2,1)], [NL(n1,2), NL(n2,2)], 'r-'); % Red line
            hold(fig,"on");
            plot(fig,[NL(n2,1), NL(n3,1)], [NL(n2,2), NL(n3,2)], 'r-');
            plot(fig,[NL(n3,1), NL(n4,1)], [NL(n3,2), NL(n4,2)], 'r-');
            plot(fig,[NL(n4,1), NL(n1,1)], [NL(n4,2), NL(n1,2)], 'r-');


            plot(fig,NL(n5,1), NL(n5,2), 'ro');
            plot(fig,NL(n6,1), NL(n6,2), 'ro');
            plot(fig,NL(n7,1), NL(n7,2), 'ro');
            plot(fig,NL(n8,1), NL(n8,2), 'ro');
            % Find the centroid of the quadrilateral for labeling
            xm = (NL(n1,1) + NL(n2,1) + NL(n3,1) + NL(n4,1)) / 4;
            ym = (NL(n1,2) + NL(n2,2) + NL(n3,2) + NL(n4,2)) / 4;
            %text(fig,xm, ym, num2str(i), 'Color', 'magenta', 'FontSize', 8, 'HorizontalAlignment', 'center');
        end    

    case 'D2QU9N' % For quadrilateral elements
        for i = 1:NoE
            % Extract node indices for the current quadrilateral element
            n1 = EL(i,1);
            n2 = EL(i,2);
            n3 = EL(i,3);
            n4 = EL(i,4);
            n5 = EL(i,5);
            n6 = EL(i,6);
            n7 = EL(i,7);
            n8 = EL(i,8);
            n9 = EL(i,9);
            
            % Plot the four edges of the quadrilateral element
            plot(fig,[NL(n1,1), NL(n2,1)], [NL(n1,2), NL(n2,2)], 'r-'); % Red line
            hold(fig,"on");
            plot(fig,[NL(n2,1), NL(n3,1)], [NL(n2,2), NL(n3,2)], 'r-');
            plot(fig,[NL(n3,1), NL(n4,1)], [NL(n3,2), NL(n4,2)], 'r-');
            plot(fig,[NL(n4,1), NL(n1,1)], [NL(n4,2), NL(n1,2)], 'r-');


            plot(fig,NL(n5,1), NL(n5,2), 'ro');
            plot(fig,NL(n6,1), NL(n6,2), 'ro');
            plot(fig,NL(n7,1), NL(n7,2), 'ro');
            plot(fig,NL(n8,1), NL(n8,2), 'ro');
            plot(fig,NL(n9,1), NL(n9,2), 'ro');
            % Find the centroid of the quadrilateral for labeling
            xm = (NL(n1,1) + NL(n2,1) + NL(n3,1) + NL(n4,1)) / 4;
            ym = (NL(n1,2) + NL(n2,2) + NL(n3,2) + NL(n4,2)) / 4;
            %text(fig,xm, ym, num2str(i), 'Color', 'magenta', 'FontSize', 8, 'HorizontalAlignment', 'center');
        end
end
for i = 1 : NoN
    plot(fig,NL(i,1), NL(i,2), 'o', 'MarkerSize', 10, 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'b'); % Small blue dots
    %text(fig,NL(i,1), NL(i,2), num2str(i), 'Color', 'w', 'FontSize', 6, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle'); % Centered white numbers
end

    
axis equal;
% Final plot settings
axis equal; % Ensure equal scaling for x and y axes
grid on; % Display grid
xlabel('X Coordinate');
ylabel('Y Coordinate');
title('Finite Element Mesh with Node and Element Labels');
hold(fig,"off"); % Release the plot hold
disp(EL);

