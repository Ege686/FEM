
function [stress_xx,stress_xy,stress_yx,stress_yy,strain_xx,strain_xy,strain_yx,strain_yy,disp_x,disp_y,X,Y ]= post_process(NL, EL, ENL,stage,fig,fig2)
    NoN= size(ENL,1);
    NoE= size(EL,1);
    NPE=size(EL,2);
    PD= size(NL,2);
    scale=2;
    
   
    
    [disp,stress,strain]= element_post_process(NL,EL,ENL);
    switch NPE
        case 3
            for i=1:NoE
                nl=EL(i,1:NPE);
                for j=1:NPE
                    X(j,i)=ENL(nl(j),1)+scale* ENL(nl(j),4*PD+1);
                    Y(j,i)=ENL(nl(j),2)+scale*ENL(nl(j),4*PD+2);
                end
                for j=1:NPE 
                    val=stress(i,:,1,1);
                    stress_xx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=stress(i,:,1,2);
                    stress_xy(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=stress(i,:,2,1);
                    stress_yx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=stress(i,:,2,2);
                    stress_yy(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,1,1);
                    strain_xx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,1,2);
                    strain_xy(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,2,1);
                    strain_yx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,2,2);
                    strain_yy(j,i)=val(1,j);
                end
                for j=1 :NPE
                    disp_x(j,i)=disp(i,j,1,1);
                end
                for j=1:NPE
                    disp_y(j,i)=disp(i,j,2,1);
                end
            end
        case 6
            EL_end=zeros(NoE:NPE);
            for e = 1:NoE
                EL_end(e,1)= EL(e,1);
                EL_end(e,2)= EL(e,4);
                EL_end(e,3)= EL(e,2);
                EL_end(e,4)= EL(e,5);
                EL_end(e,5)= EL(e,3);
                EL_end(e,6)= EL(e,6);
            end
            line=[1 ;4; 2; 5; 3; 6];
            for i=1:NoE
                nl=EL_end(i,1:NPE);
                nll=zeros(size(EL_end,2),2);
                for j=1:NPE
                    X(j,i)=ENL(nl(j),1)+scale* ENL(nl(j),4*PD+1);
                    Y(j,i)=ENL(nl(j),2)+scale*ENL(nl(j),4*PD+2);
                end
                for j=1:NPE
                    val=stress(i,:,1,1);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    stress_xx(line(j),i)=val(1,jj);
                end
                for j=1:NPE
                    val=stress(i,:,1,2);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    stress_xy(j,i)=val(1,jj);
                end
                for j=1:NPE
                    val=stress(i,:,2,1);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    stress_yx(j,i)=val(1,jj);
                end
                for j=1:NPE
                    val=stress(i,:,2,2);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    stress_yy(j,i)=val(1,jj);
                end
                for j=1:NPE
                    val=strain(i,:,1,1);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    strain_xx(j,i)=val(1,jj);
                end
                for j=1:NPE
                    val=strain(i,:,1,2);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    strain_xy(j,i)=val(1,jj);
                end
                for j=1:NPE
                    val=strain(i,:,2,1);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    strain_yx(j,i)=val(1,jj);
                end
                for j=1:NPE
                    val=strain(i,:,2,2);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    strain_yy(j,i)=val(1,jj);
                end
                for j=1 :NPE
                    jj=line(j);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    disp_x(j,i)=disp(i,jj,1,1);
                end
                for j=1:NPE
                    jj=line(j);
                    if j==1
                        jj=1;
                    elseif j==2
                        jj=1;
                    elseif j==3
                        jj=2;
                    elseif j==4
                        jj=2;
                    elseif j==5
                        jj=3;
                    elseif j==6
                        jj=3;
                    end
                    disp_y(j,i)=disp(i,jj,2,1);
                end
            end
        case 4
            for i=1:NoE
                nl=EL(i,1:NPE);
                for j=1:NPE
                    X(j,i)=ENL(nl(j),1)+scale* ENL(nl(j),4*PD+1);
                    Y(j,i)=ENL(nl(j),2)+scale*ENL(nl(j),4*PD+2);
                end
                for j=1:NPE 
                    val=stress(i,:,1,1);
                    stress_xx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=stress(i,:,1,2);
                    stress_xy(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=stress(i,:,2,1);
                    stress_yx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=stress(i,:,2,2);
                    stress_yy(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,1,1);
                    strain_xx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,1,2);
                    strain_xy(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,2,1);
                    strain_yx(j,i)=val(1,j);
                end
                for j=1:NPE
                    val=strain(i,:,2,2);
                    strain_yy(j,i)=val(1,j);
                end
                for j=1 :NPE
                    disp_x(j,i)=disp(i,j,1,1);
                end
                for j=1:NPE
                    disp_y(j,i)=disp(i,j,2,1);
                end
            end
        case 8
            Ys=[];
                Xs=[];
                gX=[];
                valss=[];
            EL_end=zeros(size(NoE):size(NPE));
            for e = 1:NoE
                EL_end(e,1)= EL(e,1);
                EL_end(e,2)= EL(e,5);
                EL_end(e,3)= EL(e,2);
                EL_end(e,4)= EL(e,6);
                EL_end(e,5)= EL(e,3);
                EL_end(e,6)= EL(e,7);
                EL_end(e,7)= EL(e,4);
                EL_end(e,8)= EL(e,8);
            end
            line=[1 ;5; 2; 6; 3; 7; 4; 8];
            for i=1:NoE
                nl=EL_end(i,1:NPE);
                for j=1:NPE
                    X(j,i)=ENL(nl(j),1)+scale* ENL(nl(j),4*PD+1);
                    Y(j,i)=ENL(nl(j),2)+scale*ENL(nl(j),4*PD+2);
                end
                for j=1:NPE 
                    val=stress(i,:,1,1);
                    stress_xx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=stress(i,:,1,2);
                    stress_xy(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=stress(i,:,2,1);
                    stress_yx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=stress(i,:,2,2);
                    stress_yy(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=strain(i,:,1,1);
                    strain_xx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=strain(i,:,1,2);
                    strain_xy(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=strain(i,:,2,1);
                    strain_yx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE
                    val=strain(i,:,2,2);
                    strain_yy(j,i)=abs(val(1,line(j)));
                end
                for j=1 :NPE
                    disp_x(j,i)=abs(disp(i,line(j),1,1));
                end
                for j=1:NPE
                    disp_y(j,i)=abs(disp(i,line(j),2,1));
                end
            end
        case 9
            Ys=[];
                Xs=[];
                gX=[];
                valss=[];
            EL_end=zeros(NoE:NPE-1);
            for e = 1:NoE
                EL_end(e,1)= EL(e,1);
                EL_end(e,2)= EL(e,5);
                EL_end(e,3)= EL(e,2);
                EL_end(e,4)= EL(e,6);
                EL_end(e,5)= EL(e,3);
                EL_end(e,6)= EL(e,7);
                EL_end(e,7)= EL(e,4);
                EL_end(e,8)= EL(e,8);
            end
            line=[1 ;5; 2; 6; 3; 7; 4; 8];
               for i=1:NoE
                nl=EL_end(i,1:NPE-1);
                for j=1:NPE-1
                    X(j,i)=ENL(nl(j),1)+scale* ENL(nl(j),4*PD+1);
                    Y(j,i)=ENL(nl(j),2)+scale*ENL(nl(j),4*PD+2);
                end
                for j=1:NPE -1
                    val=stress(i,:,1,1);
                    stress_xx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=stress(i,:,1,2);
                    stress_xy(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=stress(i,:,2,1);
                    stress_yx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=stress(i,:,2,2);
                    stress_yy(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=strain(i,:,1,1);
                    strain_xx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=strain(i,:,1,2);
                    strain_xy(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=strain(i,:,2,1);
                    strain_yx(j,i)=abs(val(1,line(j)));
                end
                for j=1:NPE-1
                    val=strain(i,:,2,2);
                    strain_yy(j,i)=abs(val(1,line(j)));
                end
                for j=1 :NPE-1
                    disp_x(j,i)=abs(disp(i,line(j),1,1));
                end
                for j=1:NPE-1
                    disp_y(j,i)=abs(disp(i,line(j),2,1));
                end
            end
    end
    if stage==1
    showw(fig,fig2,stress_xx,X,Y);

    elseif stage==2
    showw(fig,fig2,stress_xy,X,Y);

    elseif stage==3
    showw(fig,fig2,stress_yx,X,Y);

    elseif stage==4
    showw(fig,fig2,stress_yy,X,Y);

    elseif stage==5
    showw(fig,fig2,strain_xx,X,Y);

    elseif stage==6
    showw(fig,fig2,strain_xy,X,Y);

    elseif stage==7
    showw(fig,fig2,strain_yx,X,Y);

    elseif stage==8
    showw(fig,fig2,strain_yy,X,Y);

    elseif stage==9
    showw(fig,fig2,disp_x,X,Y);

    elseif stage==10
    showw(fig,fig2,disp_y,X,Y);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%                    
function [disp, stress, strain] = element_post_process(NL, EL, ENL)
    NoN = size(ENL,1);
    NoE = size(EL,1);
    NPE = size(EL,2);
    PD = size(NL,2);
    if NPE==3
        GPE=3;
    elseif NPE==4
        GPE=4;
    elseif NPE==9
        GPE=9;
    elseif NPE==8
        GPE=8;
    elseif NPE==6
        GPE=3;
    end


    disp=zeros(NoE,NPE,PD,1);
    stress=zeros(NoE, GPE,PD,PD);
    strain=zeros(NoE,GPE,PD,PD);

    for e=1:NoE
        nl=EL(e, 1:NPE);

        for i=1: NPE
            for j= 1 : PD
                disp(e,i,j,1)=ENL(nl(i),4*PD+j);
            end
        end
        x=zeros(NPE,PD);
        for i= 1:NPE
            for j= 1 : PD
                x(i,j)= NL(nl(i),j);
            end
        end
        coor=x';

        u=zeros(PD,NPE);
        for i= 1:NPE
            for j= 1 : PD
                u(j,i)=ENL(nl(i),4*PD+j);
            end
        end 
        for gp= 1: GPE
            epsilon= zeros(PD,PD);
            for i=1: NPE
                J=zeros(PD,PD);
                grad= zeros(PD,NPE);

                [xi, eta, alpha]= GaussPoint(NPE, GPE, gp);
                grad_nat= grad_N_nat(NPE, xi, eta);

                J=coor*grad_nat';
                grad=inv(J)'*grad_nat;
                epsilon= epsilon +1/2 *(dyad(grad(:,i),u(:,i))+ dyad(u(:,i),grad(:,i)));
            end

            sigma= zeros(PD,PD);
            for a=1:PD
                for b=1:PD
                    for c=1:PD
                        for d=1:PD
                            sigma(a,b)= sigma(a,b)+ constitutive(a,b,c,d)*epsilon(c,d);
                        end   
                    end
                end
            end
            for a=1:PD
                for b=1:PD
                    strain(e,gp,a,b)=epsilon(a,b);
                    stress(e,gp,a,b)=sigma(a,b);
                end 
            end
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result = grad_N_nat(NPE, xi, eta)
    PD = 2;
    result = zeros(PD,NPE);
    if (NPE == 3)
        result(1,1) = 1;
        result(1,2) = 0;
        result(1,3) = -1;

        result(2,1) = 0;
        result(2,2) = 1;
        result(2,3) = -1;
    elseif (NPE == 4)
        result(1,1) = -1/4*(1-eta);
        result(1,2) = 1/4*(1-eta);
        result(1,3) = 1/4*(1+eta);
        result(1,4) = -1/4*(1+eta);

        result(2,1) = -1/4*(1-xi);
        result(2,2) = -1/4*(1+xi);
        result(2,3) = 1/4*(1+xi);
        result(2,4) = 1/4*(1-xi);
    elseif (NPE==8)
        result(1,1) = 1/4*(1-eta)*(2*xi+eta);
        result(1,2) = 1/4*(1-eta)*(2*xi-eta);
        result(1,3) = 1/4*(1+eta)*(eta+2*xi);
        result(1,4) = 1/4*(1+eta)*(2*xi-eta);
        result(1,5) = -xi*(1-eta);
        result(1,6) = 1/2*(1-eta)*(1+eta);
        result(1,7) = -xi*(1+eta);
        result(1,8) = -1/2*(1-eta)*(1+eta);

        result(2,1) = 1/4*(1-xi)*(xi+2*eta);
        result(2,2) = 1/4*(1+xi)*(2*eta-xi);
        result(2,3) = 1/4*(1+xi)*(2*eta+xi);
        result(2,4) = 1/4*(2*eta-xi)*(1-xi);
        result(2,5) = -1/2*(1-xi)*(1+xi);
        result(2,6) = -(1+xi)*eta;
        result(2,7) = 1/2*(1-xi)*(1+xi);
        result(2,8) = -1*(1-xi)*eta;
        
    elseif (NPE==9)
        result(1,1) = 1/4*(1-eta)*(1-2*xi)*eta;
        result(1,2) = -1/4*(1-eta)*(1+2*xi)*eta;
        result(1,3) = 1/4*(1+eta)*(1+2*xi)*eta;
        result(1,4) = -1/4*(1+eta)*(1-2*xi)*eta;
        result(1,5) = eta*xi*(1-eta);
        result(1,6) = 1/2*(1-eta)*(1+2*xi)*(1+eta);
        result(1,7) = -eta*xi*(1+eta);
        result(1,8) = -1/2*(1-eta)*(1-2*xi)*(1+eta);
        result(1,9) = -2*(1-eta)*(xi)*(1+eta);

        result(2,1) = 1/4*(1-xi) * xi * (1-2*eta);
        result(2,2) = -1/4*(1+xi) * xi * (1-2*eta);
        result(2,3) = 1/4*(1+xi) * xi * (1+2*eta);
        result(2,4) = -1/4*(1-xi) * xi * (1+2*eta);
        result(2,5) = 1/2 * (1-xi) * (1+xi) * (2*eta-1);
        result(2,6) = -(1+xi) * xi * eta;
        result(2,7) = 1/2 * (1-xi) * (1+xi) * (1+2*eta);
        result(2,8) = (1-xi) * xi * eta;
        result(2,9) = -2 * (1-xi) * (1+xi) * eta;
    elseif NPE==6
        result(1,1) = -1+4*xi;
        result(1,2) = 0;
        result(1,3) = -3+4*xi+4*eta;
        result(1,4) = 4*eta;
        result(1,5) = -4*eta;
        result(1,6) = -4*(-1+eta+2*xi);

        result(2,1) = 0;
        result(2,2) = -1+4*eta;
        result(2,3) = -3+4*xi+4*eta;
        result(2,4) = 4*xi;
        result(2,5) = -4*(-1+2*eta+xi);
        result(2,6) = -4*xi;   
    end

end

function result = N_physical(NPE, xi, eta,xis,etas)
    PD = 2;
    result = zeros(1,PD);
    if (NPE == 3)
        result(1,1) = xi*xis(1,1);
        result(1,1) = result(1,1)+eta*xis(1,2);
        result(1,1) = result(1,1)+(1-xi-eta)*xis(1,3);

        result(1,2) = xi*etas(1,1);
        result(1,2) = result(1,2)+eta*etas(1,2);
        result(1,2) = result(1,2)+(1-xi-eta)*etas(1,3);
    elseif (NPE == 4)
        result(1,1) = 1/4*(1-eta)*(1-xi)*xis(1,1);
        result(1,1) = result(1,1)+1/4*(1+eta)*(1-xi)*xis(1,2);
        result(1,1) = result(1,1)+1/4*(1+eta)*(1+xi)*xis(1,3);
        result(1,1) = result(1,1)+1/4*(1+eta)*(1+xi)*xis(1,4);

        result(1,2) = 1/4*(1-eta)*(1-xi)*etas(1,1);
        result(1,2) = result(1,2)+1/4*(1+eta)*(1-xi)*etas(1,2);
        result(1,2) = result(1,2)+1/4*(1+eta)*(1+xi)*etas(1,3);
        result(1,2) = result(1,2)+1/4*(1+eta)*(1+xi)*etas(1,4);
    elseif (NPE==8)
        result(1,1) = -1/4*(1-eta)*(1+xi+eta)*(1-xi)*xis(1,1);
        result(1,1) = result(1,1)-1/4*(1-eta)*(1-xi+eta)*(1+xi)*xis(1,2);
        result(1,1) = result(1,1)-1/4*(1+xi)*(1+eta)*(1-xi-eta)*xis(1,3);
        result(1,1) = result(1,1)-1/4*(1-xi)*(1+eta)*(1+xi-eta)*xis(1,4);
        result(1,1) = result(1,1)+1/2*(1-xi)*(1+xi)*(1-eta)*xis(1,5);
        result(1,1) = result(1,1)+1/2*(1+xi)*(1+eta)*(1-eta)*xis(1,6);
        result(1,1) = result(1,1)+1/2*(1-xi)*(1+xi)*(1+eta)*xis(1,7);
        result(1,1) = result(1,1)+1/2*(1-xi)*(1+eta)*(1-eta)*xis(1,8);

        result(1,2) = -1/4*(1-eta)*(1+xi+eta)*(1-xi)*etas(1,1);
        result(1,2) = result(1,2)-1/4*(1-eta)*(1-xi+eta)*(1+xi)*etas(1,2);
        result(1,2) = result(1,2)-1/4*(1+xi)*(1+eta)*(1-xi-eta)*etas(1,3);
        result(1,2) = result(1,2)-1/4*(1-xi)*(1+eta)*(1+xi-eta)*etas(1,4);
        result(1,2) = result(1,2)+1/2*(1-xi)*(1+xi)*(1-eta)*etas(1,5);
        result(1,2) = result(1,2)+1/2*(1+xi)*(1+eta)*(1-eta)*etas(1,6);
        result(1,2) = result(1,2)+1/2*(1-xi)*(1+xi)*(1+eta)*etas(1,7);
        result(1,2) = result(1,2)+1/2*(1-xi)*(1+eta)*(1-eta)*etas(1,8);
        
    elseif (NPE==9)
        result(1,1) = 1/4*(1-eta)*(1-xi)*eta*xi*xis(1,1);
        result(1,1) = result(1,1)-1/4*(1-eta)*(1+xi)*eta*xi*xis(1,2);
        result(1,1) = result(1,1)+1/4*(1+eta)*(1+xi)*eta*xi*xis(1,3);
        result(1,1) = result(1,1)-1/4*(1+eta)*(1-xi)*eta*xi*xis(1,4);
        result(1,1) = result(1,1)-1/2*eta*(1-xi)*(1+xi)*(1-eta)*xis(1,5);
        result(1,1) = result(1,1)+1/2*(1-eta)*(1+xi)*(1+eta)*xi*xis(1,6);
        result(1,1) = result(1,1)+1/2*eta*(1-xi)*(1+xi)*(1+eta)*xis(1,7);
        result(1,1) = result(1,1)-1/2*(1-eta)*(1-xi)*(1+eta)*xi*xis(1,8);
        result(1,1) = result(1,1)+(1+xi)*(1-eta)*(1-xi)*(1+eta)*xis(1,9);

        result(1,2) = 1/4*(1-eta)*(1-xi)*eta*xi*etas(1,1);
        result(1,2) = result(1,2)-1/4*(1-eta)*(1+xi)*eta*xi*etas(1,2);
        result(1,2) = result(1,2)+1/4*(1+eta)*(1+xi)*eta*xi*etas(1,3);
        result(1,2) = result(1,2)-1/4*(1+eta)*(1-xi)*eta*xi*etas(1,4);
        result(1,2) = result(1,2)-1/2*eta*(1-xi)*(1+xi)*(1-eta)*etas(1,5);
        result(1,2) = result(1,2)+1/2*(1-eta)*(1+xi)*(1+eta)*xi*etas(1,6);
        result(1,2) = result(1,2)+1/2*eta*(1-xi)*(1+xi)*(1+eta)*etas(1,7);
        result(1,2) = result(1,2)-1/2*(1-eta)*(1-xi)*(1+eta)*xi*etas(1,8);
        result(1,2) = result(1,2)+(1+xi)*(1-eta)*(1-xi)*(1+eta)*etas(1,9);
    elseif NPE==6
        result(1,1) = xi*(2*xi-1)*xis(1,1);
        result(1,1) = result(1,1)+eta*(2*eta-1)*xis(1,2);
        result(1,1) = result(1,1)+(1-xi-eta)*(1-2*xi-2*eta)*xis(1,3);
        result(1,1) = result(1,1)+4*eta*xi*xis(1,4);
        result(1,1) = result(1,1)+4*eta*(1-xi-eta)*xis(1,5);
        result(1,1) = result(1,1)+4*xi*(1-xi-eta)*xis(1,6);

        result(1,2) = xi*(2*xi-1)*etas(1,1);
        result(1,2) = result(1,2)+eta*(2*eta-1)*etas(1,2);
        result(1,2) = result(1,2)+(1-xi-eta)*(1-2*xi-2*eta)*etas(1,3);
        result(1,2) = result(1,2)+4*eta*xi*etas(1,4);
        result(1,2) = result(1,2)+4*eta*(1-xi-eta)*etas(1,5);
        result(1,2) = result(1,2)+4*xi*(1-xi-eta)*etas(1,6);
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function C = constitutive(i,j,k,l)
    E = 8/3;
    nu = 1/3;

    C = (E/(2*(1+nu))) * (delta(i,l) * delta(j,k) + delta(i,k) * delta(j,l)) + ((E*nu)/(1-nu^2)) * delta(i,j) * delta(k,l);
end

%------------------------------%

function delta=delta(i,j)
    if (i==j)
        delta=1;
    else 
        delta=0;
    end
end
%------------------------------------%

function A =dyad(a,b)
    PD=2;
    A=zeros(PD,PD);
    for i=1:PD
        for j=1:PD
            A(i,j)=a(i)*b(j);
        end
    end
end



function [xi, eta, alpha] = GaussPoint(NPE, GPE, gp)
    if (NPE == 4)
        if (GPE == 1)

            xi = 0; eta=0 ; alpha = 4;

        elseif (GPE == 4)
            if (gp == 1)
                xi = -1/sqrt(3); eta = -1/sqrt(3); alpha = 1;
            elseif (gp == 2)
                xi = 1/sqrt(3); eta = -1/sqrt(3); alpha = 1;
            elseif (gp == 3)
                xi = 1/sqrt(3); eta = 1/sqrt(3); alpha = 1;
            elseif (gp == 4)
                xi = -1/sqrt(3); eta = 1/sqrt(3); alpha = 1;
            end
        end
    end

    if (NPE == 3)
        if gp==1
            xi = 1/6; eta = 1/6; alpha = 1/3;
        elseif gp==2
            xi = 4/6; eta = 1/6; alpha = 1/3;
        elseif gp==3
            xi = 1/6; eta = 4/6; alpha = 1/3;
        
        end
        
    end
    if NPE==8 
        if GPE==1
            xi = 0; eta=0 ; alpha = 4;
        elseif (GPE == 8)
            if (gp == 1)
                xi = -sqrt(3)/sqrt(5); eta = -sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 2)
                 xi = sqrt(3)/sqrt(5); eta = -sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 3)
                 xi = sqrt(3)/sqrt(5); eta = sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 4)
                 xi = -sqrt(3)/sqrt(5); eta = sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 5)
                 xi = 0; eta = -sqrt(3)/sqrt(5); alpha = 40/81;
            elseif (gp == 6)
                 xi = sqrt(3)/sqrt(5); eta = 0; alpha = 40/81;
            elseif (gp == 7)
                 xi = 0; eta = sqrt(3)/sqrt(5); alpha = 40/81;
            elseif (gp == 8)
                 xi = -sqrt(3)/sqrt(5); eta = 0; alpha = 40/81;
            
            end    
        end
    end   
    if NPE==9
        if GPE==1
            xi = 0; eta=0 ; alpha = 4;
         elseif (GPE == 9)
            if (gp == 1)
                xi = -sqrt(3)/sqrt(5); eta = -sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 2)
                 xi = sqrt(3)/sqrt(5); eta = -sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 3)
                 xi = sqrt(3)/sqrt(5); eta = sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 4)
                 xi = -sqrt(3)/sqrt(5); eta = sqrt(3)/sqrt(5); alpha = 25/81;
            elseif (gp == 5)
                 xi = 0; eta = -sqrt(3)/sqrt(5); alpha = 40/81;
            elseif (gp == 6)
                 xi = sqrt(3)/sqrt(5); eta = 0; alpha = 40/81;
            elseif (gp == 7)
                 xi = 0; eta = sqrt(3)/sqrt(5); alpha = 40/81;
            elseif (gp == 8)
                 xi = -sqrt(3)/sqrt(5); eta = 0; alpha = 40/81;
            elseif (gp == 9)
                 xi = 0; eta = 0; alpha = 64/81;

            
            end    
        end
    end
    if NPE==6
       if GPE==3
           if gp==1
               xi = 1/6; eta = 1/6; alpha = 1/3;
           elseif gp==2
               xi = 4/6; eta = 1/6; alpha = 1/3;
           elseif gp==3
               xi = 1/6; eta = 4/6; alpha = 1/3;
        
           end
       end    
    end
end
function [xi, eta] = GaussPoints(NPE, GPE)
    if (NPE == 4)
        if (GPE == 1)

            xi = 0; eta=0 ; alpha = 4;

        elseif (GPE == 4)
                xi(1,1) = -1/sqrt(3); eta(1,1) = -1/sqrt(3);
                xi(1,2) = 1/sqrt(3); eta(1,2) = -1/sqrt(3);
                xi(1,3) = 1/sqrt(3); eta(1,3) = 1/sqrt(3);
                xi(1,4) = -1/sqrt(3); eta(1,4) = 1/sqrt(3);
        end
    end

    if (NPE == 3)
            xi(1,1) = 1/6; eta(1,1) = 1/6;
            xi(1,2) = 4/6; eta(1,2) = 1/6;
            xi(1,3) = 1/6; eta(1,3) = 4/6;
        
        
    end
    if NPE==8 
        if GPE==1
            xi = 0; eta=0 ; alpha = 4;
        elseif (GPE == 8)
                xi(1,1) = -sqrt(3)/sqrt(5); eta(1,1) = -sqrt(3)/sqrt(5);
                 xi(1,2) = sqrt(3)/sqrt(5); eta(1,2) = -sqrt(3)/sqrt(5);
                 xi(1,3) = sqrt(3)/sqrt(5); eta(1,3) = sqrt(3)/sqrt(5);
                 xi(1,4) = -sqrt(3)/sqrt(5); eta(1,4) = sqrt(3)/sqrt(5);
                 xi(1,5) = 0; eta(1,5) = -sqrt(3)/sqrt(5);
                 xi(1,6) = sqrt(3)/sqrt(5); eta(1,6) = 0;
                 xi(1,7) = 0; eta(1,7) = sqrt(3)/sqrt(5);
                 xi(1,8) = -sqrt(3)/sqrt(5); eta(1,8) = 0;
            
        end
    end   
    if NPE==9
        if GPE==1
            xi = 0; eta=0 ; alpha = 4;
         elseif (GPE == 9)
                 xi(1,1) = -sqrt(3)/sqrt(5); eta(1,1) = -sqrt(3)/sqrt(5);
                 xi(1,2) = sqrt(3)/sqrt(5); eta(1,2) = -sqrt(3)/sqrt(5);
                 xi(1,3) = sqrt(3)/sqrt(5); eta(1,3) = sqrt(3)/sqrt(5);
                 xi(1,4) = -sqrt(3)/sqrt(5); eta(1,4) = sqrt(3)/sqrt(5);
                 xi(1,5) = 0; eta(1,5) = -sqrt(3)/sqrt(5);
                 xi(1,6) = sqrt(3)/sqrt(5); eta(1,6) = 0;
                 xi(1,7) = 0; eta(1,7) = sqrt(3)/sqrt(5);
                 xi(1,8) = -sqrt(3)/sqrt(5); eta(1,8) = 0;
                 xi(1,9) = 0; eta(1,9) = 0;

            
            end    
    end
    if NPE==6
       if GPE==3
               xi(1,1) = 1/6; eta(1,1) = 1/6;
               xi(1,2) = 4/6; eta(1,2) = 1/6;
               xi(1,3) = 1/6; eta(1,3) = 4/6;
       end    
    end
end
    


