function K = assembleStiffness(globalNodes, globalElements, materialProps)
    % Assemble global stiffness matrix
    % materialProps: struct with fields E (modulus) and v (Poisson's ratio)
    
    numNodes = size(globalNodes, 1);
    K = zeros(2*numNodes); % Initialize global stiffness matrix
    
    for e = 1:size(globalElements, 1)
        elementNodes = globalElements(e, :);
        coords = globalNodes(elementNodes, :); % Coordinates of element nodes
        
        % Determine material (matrix or inclusion)
        isInclusion = checkIfInclusion(coords, materialProps);
        material = isInclusion ? materialProps.inclusion : materialProps.matrix;
        
        % Compute element stiffness
        ke = elementStiffness(coords, material);
        
        % Assemble into global stiffness matrix
        dof = reshape([2*elementNodes-1; 2*elementNodes], [], 1);
        K(dof, dof) = K(dof, dof) + ke;
    end
end
