function showw(fig,fig2,res,X,Y)
    cla(fig);
    patch(fig,X,Y,res,"FaceColor","interp");
    set(fig,'CLim',[min(min(res)) max(max(res))]);
    hold(fig,"on");
    colormap(fig,"jet");
    axis(fig,"equal");
    colorbar(fig);
    hold(fig,"off");

    cla(fig2);
    patch(fig2,X,Y,res,"FaceColor","interp",'EdgeColor','none');
    set(fig2,'CLim',[min(min(res)) max(max(res))]);
    hold(fig2,"on");
    colormap(fig2,"jet");
    axis(fig2,"equal");
    colorbar(fig2);
    hold(fig2,"off");
end