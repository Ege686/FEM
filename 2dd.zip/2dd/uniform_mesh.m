function [NL, EL]= uniform_mesh(d1,d2,p,m,element_type)
PD=2;
%ccordinates for the element nodes
q= [0 0; d1 0; 0 d2; d1 d2];
NoN= (p+1)*(m+1);
NPE=4;
NoE= p*m;
                    
%NL construction
NL= zeros(NoN, PD);
a= d1/p;
b= d2/m;
n=1;
for i = 1:m+1
    for j = 1:p+1
        NL(n,1)= q(1,1)+ (j-1)*a;
        NL(n,2)=q(1,2)+ (i-1)*b;
        n=n+1;
    end    
end
% Element List Generation
EL=zeros(NoE, NPE);
for i = 1:m
    for j= 1:p
        if j==1
            EL((i-1)*p+j,1)= (i-1)*(p+1)+j;
            EL((i-1)*p+j,2)= EL((i-1)*p+j,1)+ 1;
            EL((i-1)*p+j,4)= EL((i-1)*p+j,1)+ (p+1);
            EL((i-1)*p+j,3)= EL((i-1)*p+j,4) +1;
        else
            EL((i-1)*p+j,1)= EL((i-1)*p+j-1,2);
            EL((i-1)*p+j,4)= EL((i-1)*p+j-1,3);
            EL((i-1)*p+j,2)= EL((i-1)*p+j,1)+1;
            EL((i-1)*p+j,3)= EL((i-1)*p+j,4)+1;
        end
    end
end

if isequal(element_type,"D2TR3N")
    NPE_new= 3;
    EL_new= zeros (2*NoE,NPE_new);
   
    for i= 1:NoE
        EL_new(2*(i-1)+1,1)=EL(i,1);
        EL_new(2*(i-1)+1,2)=EL(i,2);
        EL_new(2*(i-1)+1,3)=EL(i,3);

        EL_new(2*(i-1)+2,1)=EL(i,1);
        EL_new(2*(i-1)+2,2)=EL(i,3);
        EL_new(2*(i-1)+2,3)=EL(i,4);
    end
       
    EL= EL_new;

elseif isequal(element_type, "D2QU9N")
   


    % Adding mid-side nodes and center node
    NPE_new = 9; % Nodes per element for D2QU9N
    EL_new = zeros(NoE, NPE_new);

    % Update NL for mid-side and center nodes
    nodeCount = size(NL, 1); % Existing node count
    for e = 1:NoE
        n1 = EL(e, 1); n2 = EL(e, 2); n3 = EL(e, 3); n4 = EL(e, 4);

        % Mid-side nodes
        n5 = nodeCount + 1; % Mid-node between n1 and n2
        n6 = nodeCount + 2; % Mid-node between n2 and n3
        n7 = nodeCount + 3; % Mid-node between n3 and n4
        n8 = nodeCount + 4; % Mid-node between n4 and n1

        % Center node
        n9 = nodeCount + 5;

        % Add new nodes to NL
        NL(n5, :) = 0.5 * (NL(n1, :) + NL(n2, :));
        NL(n6, :) = 0.5 * (NL(n2, :) + NL(n3, :));
        NL(n7, :) = 0.5 * (NL(n3, :) + NL(n4, :));
        NL(n8, :) = 0.5 * (NL(n4, :) + NL(n1, :));
        NL(n9, :) = 0.25 * (NL(n1, :) + NL(n2, :) + NL(n3, :) + NL(n4, :));

        % Update element connectivity
        EL_new(e, :) = [n1, n2, n3, n4, n5, n6, n7, n8, n9];

        % Increment node count
        nodeCount = nodeCount + 5;
    end

    EL = EL_new;
    for n=size(NL,1):-1:2
        for nn=n-1:-1:1
            if NL(n,1)==NL(nn,1)&&NL(n,2)==NL(nn,2)
                for el=1:size(EL,1)
                    for i=1:size(EL,2)
                        if EL(el,i)==n
                            EL(el,i)=nn;
                        end
                        if EL(el,i)>n
                            %disp("a "+EL(el,i));
                            EL(el,i)=EL(el,i)-1;
                            %disp("b "+EL(el,i));
                        end
                    end
                end
                NL=[NL(1:n-1,:);NL(n+1:end,:)];
            end
        end
    end
    EL_new=EL;

elseif isequal(element_type, "D2QU8N")
    NPE_new = 8; % Number of nodes per element for Q8
    EL_new = zeros(NoE, NPE_new);

    nodeCount = size(NL, 1); % Existing node count

    % Add midpoint nodes and update NL
    for e = 1:NoE
        n1 = EL(e, 1); n2 = EL(e, 2); n3 = EL(e, 3); n4 = EL(e, 4);
        n5 = nodeCount + 1; 
        n6 = nodeCount + 2; 
        n7 = nodeCount + 3; 
        n8 = nodeCount + 4; 
        
        % Add midpoint nodes
        NL(n5, :) = 0.5 * (NL(n1, :) + NL(n2, :));
        NL(n6, :) = 0.5 * (NL(n2, :) + NL(n3, :));
        NL(n7, :) = 0.5 * (NL(n3, :) + NL(n4, :));
        NL(n8, :) = 0.5 * (NL(n4, :) + NL(n1, :));

        % Update the element connectivity
        EL_new(e, :) = [n1, n2, n3, n4, n5, n6, n7, n8];
        nodeCount = nodeCount + 4;
    end
    EL = EL_new;

    % Find and remove duplicate nodes
    toDelete = false(size(NL, 1), 1); % Logical array to mark duplicates

    for n = size(NL, 1):-1:1 % Iterate backward through the node list
        for nn = n-1:-1:1 % Compare with earlier nodes
            if NL(n, 1) == NL(nn, 1) && NL(n, 2) == NL(nn, 2)
                % Mark current node for deletion
                toDelete(n) = true;

                % Update element connectivity to reference the earlier node
                for el = 1:size(EL, 1)
                    for i = 1:size(EL, 2)
                        if EL(el, i) == n
                            EL(el, i) = nn;
                        elseif EL(el, i) > n
                            EL(el, i) = EL(el, i) - 1;
                        end
                    end
                end
                break; % Exit inner loop, as the duplicate is already handled
            end
        end
    end

    % Remove marked duplicate nodes from NL
    NL(toDelete, :) = [];
end
