clc 
clear all
close all 

%x = [0 0; 2 0; 1 1];
x = [0 0; 1 0; 1 2; 0 2];

GPE = 9;

Stiffness(x,GPE)